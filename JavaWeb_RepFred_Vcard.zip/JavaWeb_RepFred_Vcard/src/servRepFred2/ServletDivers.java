package servRepFred2;
/*
 * servlet de la page "Divers"
 * m�thodes: doGet, doPost
 * 
 * @author Fredo
 *
 */

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Scanner;
import java.text.SimpleDateFormat;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import packRepFred2.Const;
import packRepFred2.CarteModel;
import packRepFred2.CarteService;
import packRepFred2.CarteModel;

public class ServletDivers extends HttpServlet {
    
    private String operatPg ;
    private String ligneFicEntree; // utilis� dans 2 blocs
    //private String nomRepTravail= "C:\\Program Files (x86)\\Apache Software Foundation\\Tomcat 9.0\\webapps\\RepFred2\\ressource\\";
    private String nomRepTravail= "";
    private String suffixeFichierVcard = ".vcf";
    
    private void chargerAttributeReq(HttpServletRequest req) {
        System.out.println("-----------------------------------------ServletDivers, chargerAttributeReq");
        
        // chargement des parametres dans la r�ponse
        req.setAttribute("titreEcran", "Divers");
        //  liens hierarchiques sur une ligne
        //  -> niveaux : 1=sommaire,    2=rien
        req.setAttribute("lgLiensNomNiv1", "sommaire");
        req.setAttribute("lgLiensAdrNiv1"  , "Sommaire");
        req.setAttribute("lgLiensNomNiv2", "rien");
    }
    public void doGet(HttpServletRequest req, HttpServletResponse resp) {
        System.out.println("-----------------------------------------ServletDivers, doGet");
        
        // chargement des parametres dans la r�ponse
        chargerAttributeReq (req);

        // chargement page
        try {               
            // ouvrir la page
            req.getRequestDispatcher("jsp/pgDivers.jsp").forward(req, resp);
        }
        catch(IOException _ex ) {
            System.out.println("Erreur : IOException : " + _ex);
        }
        catch(ServletException _ex ) {
            System.out.println("Erreur : ServletException : " + _ex);
        }
        
        System.out.println("-----------------------------------------ServletDivers, fin doGet");

    }

    
    public void doPost(HttpServletRequest req, HttpServletResponse resp) {
        
        System.out.println("-----------------------------------------ServletDivers, doPost");

        // chargement des parametres dans la r�ponse
        chargerAttributeReq (req);

        
        // Recuperation de parametres de la requete HTTP
        //operatPg
        if (req.getParameter("operatPg")==null){
            // on est au 1er appel
            operatPg=Const.RIEN;
        }
        else {
            operatPg  = req.getParameter("operatPg");
        }

        //traiter la demande
        switch (operatPg) {
            case Const.CHOIX1:
                traiterCHOIX1_Unload_TabCartes( req,  resp) ;
                break;

            case Const.CHOIX2:
                traiterCHOIX2_ImportVCard( req,  resp) ;
                break;

            case Const.CHOIX3:
                traiterCHOIX3_ExportVCard( req,  resp) ;
                break;

            case Const.RIEN:
                System.out.println("req.getParameter: operatPg vide !!!!! pas bon !!!!!");
                break;
        }

        try {
                req.getRequestDispatcher("jsp/pgDivers.jsp").forward(req, resp);
            }
            catch(IOException _ex ) {
                System.out.println("Erreur : IOException : " + _ex);
            }
            catch(ServletException _ex ) {
                System.out.println("Erreur : ServletException : " + _ex);
            }
                
        
        System.out.println("-----------------------------------------ServletDivers, fin doPost");
    }
    private void traiterCHOIX1_Unload_TabCartes(HttpServletRequest req, HttpServletResponse resp) {
        System.out.println("-----------------------------------------ServletDivers, traiterCHOIX1_Unload_TabCartes deb");

        System.out.println("ServletDivers, operatPg = <" + req.getParameter("operatPg") + ">");

        //traitement page
        try {               
        
        // Initialisation du contexte JNDI et recuperation de la 
        // datasource associ�e � notre application
        Context init = new InitialContext();
        Context ctx = (Context) init.lookup("java:comp/env");
        DataSource ds = (DataSource)ctx.lookup("jdbc/baseRepFred2Rsc");
        
        // Recuperation de la connexion a la base de donnees
        Connection con = ds.getConnection();
        System.out.println("---------getConnection");
        
        // jour
        Date myDate = new Date();
        String myPattern = "yyyy.MM.dd HH.mm.ss";
        SimpleDateFormat mySimpleDateFormat = new SimpleDateFormat(myPattern);
        
        String dateFormatJourHeure = mySimpleDateFormat.format(myDate);
        System.out.println("---------dateFormatJourHeure" + dateFormatJourHeure);
        
        // Creation et execution de la requete
        String fichier = 
                  "'C:/ProgramData/MySQL/MySQL Server 5.7/Uploads/RepFred2_Cartes_unload_" 
                        + dateFormatJourHeure 
                        + ".csv'";
        String requete = "SELECT * FROM tab_cartes INTO OUTFILE " + fichier + ";";

        PreparedStatement pstmt = con.prepareStatement(requete);
        
        System.out.println(requete);
        
        ResultSet rs = pstmt.executeQuery(requete);
        req.setAttribute("msgErr", fichier + " cr��");

        }
        catch(NamingException _ex) {
            System.out.println("Erreur : NamingException : " + _ex);
        }
        catch(SQLException _ex ) {
            System.out.println("Erreur : SQLException : " + _ex);
        }
        
        System.out.println("-----------------------------------------ServletDivers, fin traiterCHOIX1_Unload_TabCartes");

    }
    
    private void traiterCHOIX2_ImportVCard(HttpServletRequest req, HttpServletResponse resp) {
        System.out.println("-----------------------------------------ServletDivers, traiterCHOIX2_ImportVCard");

        int nouveauNumero;
        String sourceFicVcardPg;
        CarteModel carteModel1;
        
        //sourceFicVcardPg
        if (req.getParameter("sourceFicVcardPg")==null){
            // on est au 1er appel
            sourceFicVcardPg=Const.RIEN;
        }
        else {
            sourceFicVcardPg  = req.getParameter("sourceFicVcardPg");
        }

        //debutNumeroPg
        if (req.getParameter("debutNumeroPg")==null){
            // on est au 1er appel
            nouveauNumero=0;
        }
        else {
            nouveauNumero = Integer.parseInt(req.getParameter("debutNumeroPg"));
        }

        //nom des fichiers 
        String suffixeNomFichierSortie = ".csv";
        String nomFichierEntree=nomRepTravail+"Vcard_"+sourceFicVcardPg+suffixeFichierVcard;
        String nomFichierSortie=nomRepTravail+"tableauAdresses_"+sourceFicVcardPg+suffixeNomFichierSortie;
        
        try {
            File fichierEntreeFile = new File(nomFichierEntree);
            Scanner fichierEntreeScanner = new Scanner(fichierEntreeFile);

            carteModel1 = new CarteModel();
            System.out.println("--fred1");


            // fichier en sortie
            //String nomEncodage = "ANSI"; // -> "java.io.UnsupportedEncodingException: ANSI" 
            String nomEncodage = "UTF-8";
            PrintWriter leFichierSortie = new PrintWriter(nomFichierSortie, nomEncodage);
            
            //enreg entete fichierSortie
            carteModel1.chargerEntete();
            leFichierSortie.println(chargerLigneFichierSortie(carteModel1));

            String debLigne;
            Boolean selLigne;

            //utilis� pour le d�coupage 
            String champsTmp=""; 

            //pour charger les champs de chaque carte
            String separChamps=";";
            char continuateurLigne='=';
            char separNomEmail='@';
            boolean booEndVCard;

            int deplacChaine;
            boolean typeAdrTrouve;
            
            //init
            carteModel1.reinitialiserTout();
            
            while (fichierEntreeScanner.hasNextLine()) {
                    ligneFicEntree= fichierEntreeScanner.nextLine();
    
                    System.out.println(ligneFicEntree);
                    
                    // concatener avec les x lignes suivantes si la ligne lue finit par "="
                    while ((ligneFicEntree.length()>0) && 
                        (continuateurLigne==ligneFicEntree.charAt(ligneFicEntree.length()-1))
                       ) {
                        champsTmp=ligneFicEntree.substring(0, ligneFicEntree.length()-1);
                        ligneFicEntree= fichierEntreeScanner.nextLine();
                        ligneFicEntree= champsTmp+ligneFicEntree;
                        System.out.println("ligneFicEntree="+ligneFicEntree);
                    }
                                
                    // attention: TODO: les ";" significatifs d'un nom sont stock�s "\;"
                      
                    // ne pas tenir compte des lignes "FN:" et des lignes vides          
                    if (ligneFicEntree.length()<3) {
                        selLigne=false;
                    } else {
                        selLigne=true;
                    }
              
                    if (selLigne) {
    
                        traduirePrintable();
                        traduireAutres(carteModel1);
                        //charger les champs:
                        //Nom
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_Nom,0);
                        if (deplacChaine==0) {
                            //Nom>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                            champsTmp=ligneFicEntree.replaceAll(Const.ID_VCARD2_Nom,"");
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
    
    
                            //5eme partie du nom 
                            deplacChaine=champsTmp.lastIndexOf(separChamps);
                            System.out.println("deplacChaine=" + deplacChaine);
                            if ((deplacChaine+1)<=champsTmp.length()) {
                                carteModel1.nom5=champsTmp.substring(deplacChaine+1,champsTmp.length());
                            }
                            System.out.println("carteModel1.nom5=" + carteModel1.nom5);
    
                            champsTmp=champsTmp.substring(0, deplacChaine);
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
                            
                            
                            //4eme partie du nom 
                            deplacChaine=champsTmp.lastIndexOf(separChamps);
                            System.out.println("deplacChaine=" + deplacChaine);
                            if ((deplacChaine+1)<=champsTmp.length()) {
                                carteModel1.nom4=champsTmp.substring(deplacChaine+1,champsTmp.length());
                            }
                            System.out.println("carteModel1.nom4=" + carteModel1.nom4);
    
                            champsTmp=champsTmp.substring(0, deplacChaine);
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
    
                            
                            //3eme partie du nom 
                            deplacChaine=champsTmp.lastIndexOf(separChamps);
                            System.out.println("deplacChaine=" + deplacChaine);
                            if ((deplacChaine+1)<=champsTmp.length()) {
                                carteModel1.nom3=champsTmp.substring(deplacChaine+1,champsTmp.length());
                            }
                            System.out.println("carteModel1.nom3=" + carteModel1.nom3);
                            
                            champsTmp=champsTmp.substring(0, deplacChaine);
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
    
                            //2eme partie du nom 
                            deplacChaine=champsTmp.lastIndexOf(separChamps);
                            System.out.println("deplacChaine=" + deplacChaine);
                            if ((deplacChaine+1)<=champsTmp.length()) {
                                carteModel1.nom2=champsTmp.substring(deplacChaine+1,champsTmp.length());
                            }
                            System.out.println("carteModel1.nom2=" + carteModel1.nom2);
                            
                            champsTmp=champsTmp.substring(0, deplacChaine);
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
    
                            //1eme partie du nom 
                            carteModel1.nom1=champsTmp;
                            System.out.println("carteModel1.nom1=" + carteModel1.nom1);
                            //Nom<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            
                        }
                        //TelCell
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_TelCell,0);
                        if (deplacChaine==0) {
                            carteModel1.telCell=ligneFicEntree.substring(Const.ID_VCARD2_TelCell.length(), ligneFicEntree.length());
                        }
                        //TelHome
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_TelHome,0);
                        if (deplacChaine==0) {
                            carteModel1.telHome=ligneFicEntree.substring(Const.ID_VCARD2_TelHome.length(), ligneFicEntree.length());
                        }
    
                        //TelWork
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_TelWork,0);
                        if (deplacChaine==0) {
                            carteModel1.telWork=ligneFicEntree.substring(Const.ID_VCARD2_TelWork.length(), ligneFicEntree.length());
                        }
    
                        //typeAdr
                        typeAdrTrouve=false;
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD4_Adr,0);
                        if (deplacChaine==0) {
                           carteModel1.typeAdr="HOME";
                           System.out.println("1.carteModel1.typeAdr=" + carteModel1.typeAdr);
                           typeAdrTrouve=true;
                           
                        }
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_Adr_Debut,0);
                        if (deplacChaine==0) {
                            //type adresse HOME ou WORK en vcard2 (4 car)
                            carteModel1.typeAdr=ligneFicEntree.substring(Const.ID_VCARD2_Adr_Debut.length(), Const.ID_VCARD2_Adr_Debut.length()+4);
                           System.out.println("2.carteModel1.typeAdr=" + carteModel1.typeAdr);
                           typeAdrTrouve=true;
                        }
    
                        //AdrBanali
                        if (typeAdrTrouve) {
                           System.out.println("carteModel1.typeAdr.length()=" + carteModel1.typeAdr.length()+"="+carteModel1.typeAdr);
                            //adresse complete
                            //AdrBanali>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                            //-enlever l'�tiquette,dont home ou work
                            champsTmp=ligneFicEntree;
                            champsTmp=champsTmp.replaceAll(Const.ID_VCARD4_Adr,"");
                            champsTmp=champsTmp.replaceAll(Const.ID_VCARD2_AdrHome,"");
                            champsTmp=champsTmp.replaceAll(Const.ID_VCARD2_AdrWork,"");
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
    
                            //7eme partie de AdrBanali
                            deplacChaine=champsTmp.lastIndexOf(separChamps);
                            System.out.println("deplacChaine=" + deplacChaine);
                            if ((deplacChaine+1)<=champsTmp.length()) {
                                carteModel1.adrBanali7=champsTmp.substring(deplacChaine+1,champsTmp.length());
                            }
                            System.out.println("carteModel1.adrBanali7=" + carteModel1.adrBanali7);
    
                            champsTmp=champsTmp.substring(0, deplacChaine);
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
                            
                            //6eme partie de AdrBanali
                            deplacChaine=champsTmp.lastIndexOf(separChamps);
                            System.out.println("deplacChaine=" + deplacChaine);
                            if ((deplacChaine+1)<=champsTmp.length()) {
                                carteModel1.adrBanali6=champsTmp.substring(deplacChaine+1,champsTmp.length());
                            }
                            System.out.println("carteModel1.adrBanali6=" + carteModel1.adrBanali6);
    
                            champsTmp=champsTmp.substring(0, deplacChaine);
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
    
                            //5eme partie de AdrBanali
                            deplacChaine=champsTmp.lastIndexOf(separChamps);
                            System.out.println("deplacChaine=" + deplacChaine);
                            if ((deplacChaine+1)<=champsTmp.length()) {
                                carteModel1.adrBanali5=champsTmp.substring(deplacChaine+1,champsTmp.length());
                            }
                            System.out.println("carteModel1.adrBanali5=" + carteModel1.adrBanali5);
    
                            champsTmp=champsTmp.substring(0, deplacChaine);
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
                            
                            
                            //4eme partie de AdrBanali
                            deplacChaine=champsTmp.lastIndexOf(separChamps);
                            System.out.println("deplacChaine=" + deplacChaine);
                            if ((deplacChaine+1)<=champsTmp.length()) {
                                carteModel1.adrBanali4=champsTmp.substring(deplacChaine+1,champsTmp.length());
                            }
                            System.out.println("carteModel1.adrBanali4=" + carteModel1.adrBanali4);
    
                            champsTmp=champsTmp.substring(0, deplacChaine);
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
    
                            
                            //3eme partie de AdrBanali
                            deplacChaine=champsTmp.lastIndexOf(separChamps);
                            System.out.println("deplacChaine=" + deplacChaine);
                            if ((deplacChaine+1)<=champsTmp.length()) {
                                carteModel1.adrBanali3=champsTmp.substring(deplacChaine+1,champsTmp.length());
                            }
                            System.out.println("carteModel1.adrBanali3=" + carteModel1.adrBanali3);
                            
                            champsTmp=champsTmp.substring(0, deplacChaine);
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
    
                            //2eme partie de AdrBanali
                            deplacChaine=champsTmp.lastIndexOf(separChamps);
                            System.out.println("deplacChaine=" + deplacChaine);
                            if ((deplacChaine+1)<=champsTmp.length()) {
                                carteModel1.adrBanali2=champsTmp.substring(deplacChaine+1,champsTmp.length());
                            }
                            System.out.println("carteModel1.adrBanali2=" + carteModel1.adrBanali2);
                            
                            champsTmp=champsTmp.substring(0, deplacChaine);
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
    
                            //1eme partie de AdrBanali
                            carteModel1.adrBanali1=champsTmp;
                            System.out.println("carteModel1.adrBanali1=" + carteModel1.adrBanali1);
                            //AdrBanali<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                        }
    
    
                        //EmailHome
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_EmailHome,0);
                        if (deplacChaine==0) {
                            carteModel1.emailHome=ligneFicEntree.substring(Const.ID_VCARD2_EmailHome.length(), ligneFicEntree.length());
                        }
    
                        //EmailWork
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_EmailWork,0);
                        if (deplacChaine==0) {
                            carteModel1.emailWork=ligneFicEntree.substring(Const.ID_VCARD2_EmailWork.length(), ligneFicEntree.length());
                        }
    
                        //Email Internet (on les cumule � EmailWork
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_EmailInternet,0);
                        if (deplacChaine==0) {
                            if(carteModel1.emailWork.length()==0) {
                                // init de carteModel1.emailWork
                                carteModel1.emailWork=ligneFicEntree.substring(Const.ID_VCARD2_EmailInternet.length(), ligneFicEntree.length());
                            } else {
                                // compl�ment � carteModel1.emailWork
                                carteModel1.emailWork=carteModel1.emailWork+" / " + ligneFicEntree.substring(Const.ID_VCARD2_EmailInternet.length(), ligneFicEntree.length());
                            }
                        }
                        
                        //Org
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_Org,0);
                        if (deplacChaine==0) {
                            champsTmp=ligneFicEntree.substring(Const.ID_VCARD2_Org.length(), ligneFicEntree.length());
                        
                            //Org>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                            champsTmp=champsTmp.replaceAll(Const.ID_VCARD2_Org,"");
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
    
                            //2eme partie de Org 
                            deplacChaine=champsTmp.lastIndexOf(separChamps);
                            System.out.println("deplacChaine=" + deplacChaine);
    
                            if (deplacChaine<0) {
                                // cas o� ORG n'a qu'1 seul champs, sans ";" final
                                // champsTmp inchang�, et carteModel1.org2 reste vide
                            } else {
                                if ((deplacChaine+1)<=champsTmp.length()) {
                                    // le 2eme mot n'est pas vide
                                    carteModel1.org2=champsTmp.substring(deplacChaine+1,champsTmp.length());
                                }
                                champsTmp=champsTmp.substring(0, deplacChaine);
                            }
                            
                            
                            System.out.println("carteModel1.org2=" + carteModel1.org2 + " deplacChaine=" + deplacChaine);
                
                            System.out.println("champsTmp=" + champsTmp);
                            System.out.println("champsTmp.length()=" + champsTmp.length());
    
                            //1eme partie de Org 
                            carteModel1.org1=champsTmp;
                            System.out.println("carteModel1.org1=" + carteModel1.org1);
                            //Org<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                        
                        }
    
                        //Title
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_Title,0);
                        if (deplacChaine==0) {
                            carteModel1.title=ligneFicEntree.substring(Const.ID_VCARD2_Title.length(), ligneFicEntree.length());
                        }
    
                        //Note
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_Note,0);
                        if (deplacChaine==0) {
                            carteModel1.note=ligneFicEntree.substring(Const.ID_VCARD2_Note.length(), ligneFicEntree.length());
                        }

                        //Full Name
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_FullName,0);
                        if (deplacChaine==0) {
                            carteModel1.fullName=ligneFicEntree.substring(Const.ID_VCARD2_FullName.length(), ligneFicEntree.length());
                        }


                        
                        
                        //EndVcard
                        deplacChaine = ligneFicEntree.indexOf(Const.ID_VCARD2_EndVcard,0);
                        booEndVCard= (deplacChaine==0);
                        
                        //fin de carte
                        if (booEndVCard) {

                            //si nom1 et nom 2 vides
                            //  - essai remplissage avec emailHome
                            if ((carteModel1.nom1.length()==0) && (carteModel1.nom2.length()==0))  {
                                if (carteModel1.emailHome.length()>0) {
                                    deplacChaine=carteModel1.emailHome.lastIndexOf(separNomEmail);
                                    carteModel1.nom1=carteModel1.emailHome.substring(0,deplacChaine);
                                    carteModel1.nom2=carteModel1.emailHome.substring(deplacChaine+1,carteModel1.emailHome.length());
                                }
                            }
                            //  - essai remplissage avec emailWork
                            if (carteModel1.nom1.length()==0) {
                                if (carteModel1.emailWork.length()>0) {
                                    deplacChaine=carteModel1.emailWork.lastIndexOf(separNomEmail);
                                    carteModel1.nom1=carteModel1.emailWork.substring(0,deplacChaine);
                                    carteModel1.nom2=carteModel1.emailWork.substring(deplacChaine+1,carteModel1.emailWork.length());
                                }

                            }
                            
                            //si nom1 seul vide
                            //  - essai remplissage avec emailHome
                            if (carteModel1.nom1.length()==0) {
                                if (carteModel1.emailHome.length()>0) {
                                    deplacChaine=carteModel1.emailHome.lastIndexOf(separNomEmail);
                                    carteModel1.nom1=carteModel1.emailHome.substring(0,deplacChaine);
                                }

                            }
                            //  - essai remplissage avec emailWork

                            if (carteModel1.nom1.length()==0) {
                                if (carteModel1.emailWork.length()>0) {
                                    deplacChaine=carteModel1.emailWork.lastIndexOf(separNomEmail);
                                    carteModel1.nom1=carteModel1.emailWork.substring(0,deplacChaine);
                                }
                                
                            }
                            
                            
                            //si nom2 seul vide
                            //  - essai remplissage avec emailHome
                            if (carteModel1.nom2.length()==0) {
                                if (carteModel1.emailHome.length()>0) {
                                    deplacChaine=carteModel1.emailHome.lastIndexOf(separNomEmail);
                                    carteModel1.nom2=carteModel1.emailHome.substring(0,deplacChaine);
                                }
                            }
                            //  - essai remplissage avec emailWork

                            if (carteModel1.nom2.length()==0) {
                                if (carteModel1.emailWork.length()>0) {
                                    deplacChaine=carteModel1.emailWork.lastIndexOf(separNomEmail);
                                    carteModel1.nom2=carteModel1.emailWork.substring(0,deplacChaine);
                                }
                            }
                            
                            //nouveau codeIdent carte
                            nouveauNumero   = nouveauNumero    + 1;
                            carteModel1.codeIdent   = "carte" + nouveauNumero   ;
                            carteModel1.sourceFicVcard =sourceFicVcardPg; 

                            //debug
                            carteModel1.afficherDebug("carteModel1");
                            
                            //ecrire enreg
                            leFichierSortie.println(chargerLigneFichierSortie(carteModel1));
                            
                            // traiter la carte
                            
                            //reinit la carte
                            carteModel1.reinitialiserTout();
                            
                        }
                    } else {
                        System.out.println("===>!!! ligne pas s�lectionn�e" );
                        
                    }
            }
            
            fichierEntreeScanner.close();
                      
            System.out.println("--fred4");
              
            leFichierSortie.close();
            System.out.println("--fred5");
                  
            req.setAttribute("msgErr", nomFichierSortie + " cr��");
                  
             }

          catch(IOException _ex ) {
              System.out.println("Erreur : IOException : " + _ex);
              req.setAttribute("msgErr", "Erreur : IOException : " + _ex);

          }
        
              System.out.println("-----------------------------------------ServletDivers, fin traiterCHOIX2_ImportVCard");
    
    }

    
    private void traiterCHOIX3_ExportVCard(HttpServletRequest req, HttpServletResponse resp) {
        System.out.println("-----------------------------------------ServletDivers, traiterCHOIX3_ExportVCard");

        CarteModel carteModel1;
        int i=0;

        //nom des fichiers 
        //String nomFichierSortie=nomRepTravail+"Vcard_RepFred2"+suffixeFichierVcard;
        String nomFichierSortie=this.getServletContext().getRealPath(req.getContextPath())+suffixeFichierVcard;

        carteModel1 = new CarteModel();
        System.out.println("--fred1");

        //utilis� pour le d�coupage 
        String champsTmp=""; 

        try {

            // fichier en sortie
            String nomEncodage = "UTF-8";
            PrintWriter leFichierSortie = new PrintWriter(nomFichierSortie, nomEncodage);
            
            //init
            carteModel1.reinitialiserTout();

            // Initialisation du contexte JNDI et recuperation de la 
            // datasource associ�e � notre application
            Context init = new InitialContext();
            Context ctx = (Context) init.lookup("java:comp/env");
            DataSource ds = (DataSource)ctx.lookup("jdbc/baseRepFred2Rsc");
            System.out.println("---------fred3");
            
            // Recuperation de la connexion a la base de donnees
            Connection con = ds.getConnection();
            System.out.println("---------fred4");
            
            // Creation et execution de la requete
            String requete = CarteModel.SQL_DEB_SELECT +
            " ORDER BY carte_sourceFicVcard ASC , carte_nom1 ASC ;";
            
            PreparedStatement pstmt = con.prepareStatement(requete);
            
            System.out.println(requete);
            
            ResultSet rs = pstmt.executeQuery(requete);
            String ligneFichier="";
            char caracRC='\r';
            char caracSeparMot=';';
            char caracEspace=' ';


            // Si on a un resultat
            while (rs.next()) {
                i=+1;
                //debug
                carteModel1.ChargerResultatRequete(rs);
                carteModel1.afficherDebug("carteModel1");
                ligneFichier=
                          Const.ID_VCARD2_BeginVcard   + caracRC 
                        + Const.ID_VCARD2_VersionVcard + caracRC 
                        + Const.ID_VCARD2_Nom 
                        + carteModel1.nom2 + caracSeparMot 
                        + carteModel1.nom1 + caracSeparMot 
                        + carteModel1.nom3 + caracSeparMot 
                        + carteModel1.nom4 + caracSeparMot 
                        + carteModel1.nom5 
                        + caracRC 
                        ; 
                        
                if (carteModel1.fullName.length()>0){
                    ligneFichier =  ligneFichier
                          + Const.ID_VCARD2_FullName
                          + carteModel1.fullName
                          + caracRC 
                          ;
                }
                      
                if (carteModel1.telCell.length()>0){
                    ligneFichier =  ligneFichier
                          + Const.ID_VCARD2_TelCell
                          + carteModel1.telCell
                          + caracRC 
                          ;
                }
                      
                  if (carteModel1.telHome.length()>0){
                      ligneFichier =  ligneFichier
                            + Const.ID_VCARD2_TelHome
                            + carteModel1.telHome
                            + caracRC 
                            ;
                  }
                        
                  if (carteModel1.telWork.length()>0){
                      ligneFichier =  ligneFichier
                            + Const.ID_VCARD2_TelWork
                            + carteModel1.telWork
                            + caracRC 
                            ;
                  }

                  if (carteModel1.adrBanali1.length()+
                      carteModel1.adrBanali2.length()+
                      carteModel1.adrBanali3.length()+
                      carteModel1.adrBanali4.length()+
                      carteModel1.adrBanali5.length()+
                      carteModel1.adrBanali6.length()+
                      carteModel1.adrBanali7.length()
                      >0){
                      ligneFichier =  ligneFichier
                            + Const.ID_VCARD2_Adr_Debut
                            + carteModel1.typeAdr+":"
                            + carteModel1.adrBanali1 + caracSeparMot 
                            + carteModel1.adrBanali2 + caracSeparMot 
                            + carteModel1.adrBanali3 + caracSeparMot 
                            + carteModel1.adrBanali4 + caracSeparMot 
                            + carteModel1.adrBanali5 + caracSeparMot 
                            + carteModel1.adrBanali6 + caracSeparMot 
                            + carteModel1.adrBanali7 
                            + caracRC 
                            ;
                  }

                  if (carteModel1.emailWork.length()>0){
                      ligneFichier =  ligneFichier
                            + Const.ID_VCARD2_EmailWork
                            + carteModel1.emailWork
                            + caracRC 
                            ;
                  }
                  
                  if (carteModel1.emailHome.length()>0){
                      ligneFichier =  ligneFichier
                            + Const.ID_VCARD2_EmailHome
                            + carteModel1.emailHome
                            + caracRC 
                            ;
                  }
                        
                  if (carteModel1.org1.length()+
                      carteModel1.org2.length()
                      >0){
                          ligneFichier =  ligneFichier
                                + Const.ID_VCARD2_Org
                                + carteModel1.org1 + caracSeparMot 
                                + carteModel1.org2 
                                + caracRC 
                                ;
                      }
                  
                  if (carteModel1.title.length()>0){
                      ligneFichier =  ligneFichier
                            + Const.ID_VCARD2_Title
                            + carteModel1.title
                            + caracRC 
                            ;
                  }
                        
                  if (carteModel1.note.length()>0){
                      ligneFichier =  ligneFichier
                            + Const.ID_VCARD2_Note
                            + carteModel1.note
                            + caracRC 
                            ;
                  }
                  
                  ligneFichier =  ligneFichier
                        + Const.ID_VCARD2_EndVcard
                        + caracRC 
                        ;
                        
                leFichierSortie.println(ligneFichier);
                
                //reinit la carte
                carteModel1.reinitialiserTout();
                            
            }
            
                      
            System.out.println("--fred4, i=" +i);
              
            leFichierSortie.close();
                  
            req.setAttribute("msgErr", nomFichierSortie + " cr��");
                  
             }

            catch(IOException _ex ) {
              System.out.println("Erreur : IOException : " + _ex);
              req.setAttribute("msgErr", "Erreur : IOException : " + _ex);
            }
            catch(NamingException _ex) {
                System.out.println("Erreur : NamingException : " + _ex);
                req.setAttribute("msgErr", "Erreur : NamingException : " + _ex);
            }
            catch(SQLException _ex ) {
                System.out.println("Erreur : SQLException : " + _ex);
                req.setAttribute("msgErr", "Erreur : SQLException : " + _ex);
            }

        System.out.println("-----------------------------------------ServletDivers, fin traiterCHOIX3_ExportVCard");
    
    }
    
    
    private void traduirePrintable() {
        // d'abord les "doubles"
        
        ligneFicEntree=ligneFicEntree.replaceAll("=C2=A0", " "); // espace non s�cable
    
        ligneFicEntree=ligneFicEntree.replaceAll("=C3=89", "E");
        ligneFicEntree=ligneFicEntree.replaceAll("=C3=8E", "�");
        ligneFicEntree=ligneFicEntree.replaceAll("=C3=A9", "�");
        ligneFicEntree=ligneFicEntree.replaceAll("=C3=A7", "�");
        ligneFicEntree=ligneFicEntree.replaceAll("=C3=A8", "�");
        ligneFicEntree=ligneFicEntree.replaceAll("=C3=AA", "�");
        ligneFicEntree=ligneFicEntree.replaceAll("=C3=AE", "�");
        ligneFicEntree=ligneFicEntree.replaceAll("=C3=B9", "�");
        ligneFicEntree=ligneFicEntree.replaceAll("=C3=BB", "�");
               
    
        // ensuite les <> "=C3"
    
        ligneFicEntree=ligneFicEntree.replaceAll("=0A", " // "); // retour � la ligne
        
        ligneFicEntree=ligneFicEntree.replaceAll("=20", " ");
        ligneFicEntree=ligneFicEntree.replaceAll("=21", "!");
        ligneFicEntree=ligneFicEntree.replaceAll("=22", " "); //TODO: double quote 
        ligneFicEntree=ligneFicEntree.replaceAll("=23", "#");
        ligneFicEntree=ligneFicEntree.replaceAll("=24", "$");
        ligneFicEntree=ligneFicEntree.replaceAll("=25", "%");
        ligneFicEntree=ligneFicEntree.replaceAll("=26", "&");
        ligneFicEntree=ligneFicEntree.replaceAll("=27", "'");
        ligneFicEntree=ligneFicEntree.replaceAll("=28", "(");
        ligneFicEntree=ligneFicEntree.replaceAll("=29", ")");
        ligneFicEntree=ligneFicEntree.replaceAll("=2A", "*");
        ligneFicEntree=ligneFicEntree.replaceAll("=2B", "+");
        ligneFicEntree=ligneFicEntree.replaceAll("=2C", ",");
        ligneFicEntree=ligneFicEntree.replaceAll("=2D", "-");
        ligneFicEntree=ligneFicEntree.replaceAll("=2E", ".");
        ligneFicEntree=ligneFicEntree.replaceAll("=2F", "/");
    
        ligneFicEntree=ligneFicEntree.replaceAll("=30", "0");
        ligneFicEntree=ligneFicEntree.replaceAll("=31", "1");
        ligneFicEntree=ligneFicEntree.replaceAll("=32", "2");
        ligneFicEntree=ligneFicEntree.replaceAll("=33", "3");
        ligneFicEntree=ligneFicEntree.replaceAll("=34", "4");
        ligneFicEntree=ligneFicEntree.replaceAll("=35", "5");
        ligneFicEntree=ligneFicEntree.replaceAll("=36", "6");
        ligneFicEntree=ligneFicEntree.replaceAll("=37", "7");
        ligneFicEntree=ligneFicEntree.replaceAll("=38", "8");
        ligneFicEntree=ligneFicEntree.replaceAll("=39", "9");
        ligneFicEntree=ligneFicEntree.replaceAll("=3A", ":");
        ligneFicEntree=ligneFicEntree.replaceAll("=3B", ";");
        ligneFicEntree=ligneFicEntree.replaceAll("=3C", "<");
        ligneFicEntree=ligneFicEntree.replaceAll("=3D", "=");
        ligneFicEntree=ligneFicEntree.replaceAll("=3E", ">");
        ligneFicEntree=ligneFicEntree.replaceAll("=3F", "?");
    
        ligneFicEntree=ligneFicEntree.replaceAll("=40", "@");
        ligneFicEntree=ligneFicEntree.replaceAll("=41", "A");
        ligneFicEntree=ligneFicEntree.replaceAll("=42", "B");
        ligneFicEntree=ligneFicEntree.replaceAll("=43", "C");
        ligneFicEntree=ligneFicEntree.replaceAll("=44", "D");
        ligneFicEntree=ligneFicEntree.replaceAll("=45", "E");
        ligneFicEntree=ligneFicEntree.replaceAll("=46", "F");
        ligneFicEntree=ligneFicEntree.replaceAll("=47", "G");
        ligneFicEntree=ligneFicEntree.replaceAll("=48", "H");
        ligneFicEntree=ligneFicEntree.replaceAll("=49", "I");
        ligneFicEntree=ligneFicEntree.replaceAll("=4A", "J");
        ligneFicEntree=ligneFicEntree.replaceAll("=4B", "K");
        ligneFicEntree=ligneFicEntree.replaceAll("=4C", "L");
        ligneFicEntree=ligneFicEntree.replaceAll("=4D", "M");
        ligneFicEntree=ligneFicEntree.replaceAll("=4E", "N");
        ligneFicEntree=ligneFicEntree.replaceAll("=4F", "O");
    
        ligneFicEntree=ligneFicEntree.replaceAll("=50", "P");
        ligneFicEntree=ligneFicEntree.replaceAll("=51", "Q");
        ligneFicEntree=ligneFicEntree.replaceAll("=52", "R");
        ligneFicEntree=ligneFicEntree.replaceAll("=53", "S");
        ligneFicEntree=ligneFicEntree.replaceAll("=54", "T");
        ligneFicEntree=ligneFicEntree.replaceAll("=55", "U");
        ligneFicEntree=ligneFicEntree.replaceAll("=56", "V");
        ligneFicEntree=ligneFicEntree.replaceAll("=57", "W");
        ligneFicEntree=ligneFicEntree.replaceAll("=58", "X");
        ligneFicEntree=ligneFicEntree.replaceAll("=59", "Y");
        ligneFicEntree=ligneFicEntree.replaceAll("=5A", "Z");
    
        ligneFicEntree=ligneFicEntree.replaceAll("=61", "a");
        ligneFicEntree=ligneFicEntree.replaceAll("=62", "b");
        ligneFicEntree=ligneFicEntree.replaceAll("=63", "c");
        ligneFicEntree=ligneFicEntree.replaceAll("=64", "d");
        ligneFicEntree=ligneFicEntree.replaceAll("=65", "e");
        ligneFicEntree=ligneFicEntree.replaceAll("=66", "f");
        ligneFicEntree=ligneFicEntree.replaceAll("=67", "g");
        ligneFicEntree=ligneFicEntree.replaceAll("=68", "h");
        ligneFicEntree=ligneFicEntree.replaceAll("=69", "i");
        ligneFicEntree=ligneFicEntree.replaceAll("=6A", "j");
        ligneFicEntree=ligneFicEntree.replaceAll("=6B", "k");
        ligneFicEntree=ligneFicEntree.replaceAll("=6C", "l");
        ligneFicEntree=ligneFicEntree.replaceAll("=6D", "m");
        ligneFicEntree=ligneFicEntree.replaceAll("=6E", "n");
        ligneFicEntree=ligneFicEntree.replaceAll("=6F", "o");
    
        ligneFicEntree=ligneFicEntree.replaceAll("=70", "p");
        ligneFicEntree=ligneFicEntree.replaceAll("=71", "q");
        ligneFicEntree=ligneFicEntree.replaceAll("=72", "r");
        ligneFicEntree=ligneFicEntree.replaceAll("=73", "s");
        ligneFicEntree=ligneFicEntree.replaceAll("=74", "t");
        ligneFicEntree=ligneFicEntree.replaceAll("=75", "u");
        ligneFicEntree=ligneFicEntree.replaceAll("=76", "v");
        ligneFicEntree=ligneFicEntree.replaceAll("=77", "w");
        ligneFicEntree=ligneFicEntree.replaceAll("=78", "x");
        ligneFicEntree=ligneFicEntree.replaceAll("=79", "y");
        ligneFicEntree=ligneFicEntree.replaceAll("=7A", "z");
    
        ligneFicEntree=ligneFicEntree.replaceAll(";CHARSET=UTF-8", "");
        ligneFicEntree=ligneFicEntree.replaceAll(";ENCODING=QUOTED-PRINTABLE", "");

        //debug
        System.out.println(ligneFicEntree+" (apr�s traduirePrintable)");
        
    }


    private void traduireAutres(CarteModel carteModel1) {
        //"EMAIL;PREF=1:" utilis� dans Vcard4 (thunderbird)
        ligneFicEntree=ligneFicEntree.replaceAll(";PREF=1", ";HOME");
        System.out.println(ligneFicEntree+" (apr�s traduireAutres1)");
        
        // Tel X-Domicile <=> HOME
        ligneFicEntree=ligneFicEntree.replaceAll(Const.ID_VCARD2_TelDomicile, Const.ID_VCARD2_TelHome);
        //TODO: sauf si TelHome d�j� renseign�
        System.out.println(ligneFicEntree+" (apr�s traduireAutres2)");
        
        // Tel Pref <=> HOME
        ligneFicEntree=ligneFicEntree.replaceAll(Const.ID_VCARD2_TelPref, Const.ID_VCARD2_TelHome);
        System.out.println(ligneFicEntree+" (apr�s traduireAutres3)");
        
        // � ex�cuter � la fin des traduction: autres ";PREF" : utilis�s par les TEL, les ADR, et EMAIL X-INTERNET
        ligneFicEntree=ligneFicEntree.replaceAll(";PREF", "");
        
        //debug
        System.out.println(ligneFicEntree+" (apr�s traduireAutres)");
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    private String chargerLigneFichierSortie(CarteModel locCM){
        char caracTabul='\t';
        String locStr="";

        locStr=locCM.codeIdent + caracTabul;
        locStr=locStr + locCM.sourceFicVcard + caracTabul;

        locStr=locStr + locCM.nom1 + caracTabul;
        locStr=locStr + locCM.nom2 + caracTabul;
        locStr=locStr + locCM.nom3 + caracTabul;
        locStr=locStr + locCM.nom4 + caracTabul;
        locStr=locStr + locCM.nom5 + caracTabul;

        locStr=locStr + locCM.telCell + caracTabul;
        locStr=locStr + locCM.telHome + caracTabul;
        locStr=locStr + locCM.telWork + caracTabul;

        locStr=locStr + locCM.typeAdr    + caracTabul;
        locStr=locStr + locCM.adrBanali1 + caracTabul;
        locStr=locStr + locCM.adrBanali2 + caracTabul;
        locStr=locStr + locCM.adrBanali3 + caracTabul;
        locStr=locStr + locCM.adrBanali4 + caracTabul;
        locStr=locStr + locCM.adrBanali5 + caracTabul;
        locStr=locStr + locCM.adrBanali6 + caracTabul;
        locStr=locStr + locCM.adrBanali7 + caracTabul;

        locStr=locStr + locCM.emailHome + caracTabul;
        locStr=locStr + locCM.emailWork + caracTabul;

        locStr=locStr + locCM.org1 + caracTabul;
        locStr=locStr + locCM.org2 + caracTabul;

        locStr=locStr + locCM.title + caracTabul;
        locStr=locStr + locCM.note  + caracTabul;
        
        return locStr; 

    }
    
}   
    
