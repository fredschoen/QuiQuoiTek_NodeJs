/*
 * Created on 9 janv. 2006
 */
package servRepFred2;

/*
 * 
 * Servlet de la page "liste des cartes"
 * m�thodes: doGet, doPost
 * @author Fredo
 *
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import packRepFred2.Outils;

import java.util.Date;
import java.text.*;

public class ServletCartes extends HttpServlet {	
    // propos� par Eclipse
    private static final long serialVersionUID = 1L;
	
    /**************************************************************/
	public void doGet(HttpServletRequest req, HttpServletResponse resp) {
		/**************************************************************/
		/* doGet ex�cut� quand on arrive de '<a href="ListeCartes">' */
		System.out.println("-----------------------------------------ServletCartes, doGet");

		try {
			HttpSession session = req.getSession(false);
			if (session==null) {
				System.out.println("ServletCartes, (session == null)");
				req.setAttribute("msgErr", "votre session est p�rim�e (timeout)");
				req.getRequestDispatcher("jsp/pgSommaire.jsp").forward(req, resp);
			}
			else {

				// chargement des parametres dans la r�ponse
				req.setAttribute("titreEcran", "Liste des cartes");

				System.out.println("ServletCartes, doGet " +session.getAttribute("critTri"));

				
				//  liens hierarchiques sur une ligne
				req.setAttribute("lgLiensNomNiv1", "rien");
				
				//traiter
				TraiterRequete(req, resp);

				// trace
				System.out.println("ServletCartes, fin doGet");
			}
		}
		catch(IOException _ex ) {
			System.out.println("Erreur : IOException : " + _ex);
		}
		catch(ServletException _ex ) {
			System.out.println("Erreur : ServletException : " + _ex);
		}
	}

	
	/**************************************************************/
	public void doPost(HttpServletRequest req, HttpServletResponse resp) {
		/**************************************************************/
		Date maintenant = new Date();
		System.out.println("-----------------------------------------ServletCartes doPost � " + DateFormat.getTimeInstance().format(maintenant));
		
		try {
			HttpSession session = req.getSession(false);
			if (session==null) {
				System.out.println("ServletCartes, (session == null)");
				req.setAttribute("msgErr", "votre session est p�rim�e (timeout)");
				req.getRequestDispatcher("jsp/pgSommaire.jsp").forward(req, resp);
			}
			else {

				
				TraiterRequete(req, resp);
				
			}
		}
		
		catch(IOException _ex ) {
			System.out.println("Erreur : IOException : " + _ex);
		}
		catch(ServletException _ex ) {
			System.out.println("Erreur : ServletException : " + _ex);
		}
	}
	
	/**************************************************************/
	private void TraiterRequete(HttpServletRequest req, HttpServletResponse resp) {
		/**************************************************************/
		Date maintenant = new Date();
		System.out.println("-----------------------------------------ServletCartes TraiterRequete � " + DateFormat.getTimeInstance().format(maintenant));
		String msgErr="";

        // initialiser la r�ponse � "rien"
		req.setAttribute("code1","fin---fin");
		
        HttpSession session = req.getSession(false);
        if (session==null) {
            System.out.println("ServletCartes, (session == null)");
            req.setAttribute("msgErr", "votre session est p�rim�e (timeout)");
        }
        else {
            
    		try {
    				System.out.println("---------fred0");
    				
    				// Recuperation de parametres de la requete
    				String critTri          = req.getParameter("critTri");
    				String filtreSourceFicVcard = req.getParameter("filtreSourceFicVcard");
    				String filtreNom1    = req.getParameter("filtreNom1");
    				
    				System.out.println("---------fred1="+filtreSourceFicVcard + "-" + filtreNom1);
    
    				if (critTri == null) {
    					System.out.println("---------fred, on ne vient pas de la liste des cartes");
    					System.out.println("---------session 'critTri'="+session.getAttribute("critTri"));
    
    					critTri=session.getAttribute("critTri").toString();
    					filtreSourceFicVcard=session.getAttribute("filtreSourceFicVcard").toString();
    					filtreNom1=session.getAttribute("filtreNom1").toString();
    				}
    				else {
    					// sauver les crit�res, sans "session"
    					System.out.println("---------fred, on vient de la liste des cartes");
    					session.setAttribute("critTri", critTri);
    					session.setAttribute("filtreSourceFicVcard",filtreSourceFicVcard);
    					session.setAttribute("filtreNom1",filtreNom1);
    					
    				}
    				
    				System.out.println("ServletCartes doPost critTri=<" + critTri + ">");
    				System.out.println("---------fred11="+filtreSourceFicVcard + "-" + filtreNom1);
    				
    				// chargement des parametres dans la r�ponse
    				req.setAttribute("titreEcran", "Liste des cartes");
    				//  -> lgLiensNomNiv1, 2, 3
    				req.setAttribute("lgLiensNomNiv1", "sommaire");
    				req.setAttribute("lgLiensAdrNiv1"  , "Sommaire");
    
    				req.setAttribute("lgLiensNomNiv2", "rien");
    				System.out.println("---------fred2");
    
    				req.setAttribute("filtreSourceFicVcard", Outils.prepareTexteHTML(filtreSourceFicVcard));
    				req.setAttribute("filtreNom1", Outils.prepareTexteHTML(filtreNom1));
    				
    				// Initialisation du contexte JNDI et recuperation de la 
    				// datasource associ�e � notre application
    				Context init = new InitialContext();
    				Context ctx = (Context) init.lookup("java:comp/env");
    				DataSource ds = (DataSource)ctx.lookup("jdbc/baseRepFred2Rsc");
    				System.out.println("---------fred3");
    				
    				// Recuperation de la connexion a la base de donnees
    				Connection con = ds.getConnection();
    				System.out.println("---------fred4");
    				
    				// Creation et execution de la requete
    				String select = "SELECT " +
      				"  carte_codeIdent " +
    				", carte_sourceFicVcard " +
    				", carte_nom1 " +
                    ", carte_nom2 " +
    				" FROM tab_cartes ";
    				
    				
    				// filtre sur sourceFicVcardPg
    				select=select+Outils.txtWherePourListe(filtreSourceFicVcard, filtreNom1);
                    if (Outils.erreur.length()>0){
                        System.out.println("---------Outils.erreur xxx=" + Outils.erreur);
                        //noter l'erreur
                        if (msgErr.length()>0) msgErr=msgErr+"<BR>";
                        msgErr=msgErr+"txtWherePourListe: " + Outils.erreur;
                    }
    				// ordre de tri
    				select=select+Outils.txtOrderBy(critTri);
                    if (Outils.erreur.length()>0){
                        System.out.println("---------Outils.erreur xxx=" + Outils.erreur);
                        //noter l'erreur
                        if (msgErr.length()>0) msgErr=msgErr+"<BR>";
                        msgErr=msgErr+"txtOrderBy: " + Outils.erreur;
                    }
    				select=select+";";
    				
    
    				System.out.println(select);
    				
    				// statement
    				PreparedStatement pstmt = con.prepareStatement(select);
    				ResultSet rs = pstmt.executeQuery(select);
    				
    				// resultat
    				int i=0;
    				int j=0;
    				while (rs.next()) {
    					i= i+1;
    					System.out.println("ligne " + Integer.toString(i) + " lue : " +
    					         "1=<" + rs.getString(1) + ">" +
    							 "2=<" + rs.getString(2)+ ">" +
    							 "3=<" + rs.getString(3) + ">" );
    					
    					j=0;
    					req.setAttribute("codeIdentPg"   + Integer.toString(i) , rs.getString(++j));
    					req.setAttribute("sourceFicVcardPg"    + Integer.toString(i) , rs.getString(++j));
    					req.setAttribute("nom1Pg" + Integer.toString(i) , rs.getString(++j));
    					req.setAttribute("nom2Pg" + Integer.toString(i) , rs.getString(++j));
    					
    					//req.setAttribute("codeIdentPg"   + Integer.toString(i),new String(rs.getString(1)));
    				}
    				i=i+1;
    				req.setAttribute("codeIdentPg"   + Integer.toString(i),"fin---fin");
    				req.setAttribute("nombreCartes" , Integer.toString(i));
                    req.setAttribute("msgErr" , msgErr);
    	
    				System.out.println("1=<" + req.getAttribute("code1") + ">" );
    				System.out.println("1=<" + req.getAttribute("groupe1") + ">" );
    			}
    		
    		
    		catch(NamingException _ex) {
    			System.out.println("ServletCartes doPost KO : NamingException : " + _ex);
                req.setAttribute("msgErr" , "ServletCartes doPost KO : NamingException : " + _ex );
    		}
    		catch(SQLException _ex ) {
    			System.out.println("ServletCartes doPost KO : SQLException : " + _ex);
                req.setAttribute("msgErr" , "ServletCartes doPost KO : SQLException : " + _ex);
    			
    		}
        }

		try {
            // On renvoie sur la page de resultat
            req.getRequestDispatcher("jsp/pgCartes.jsp").forward(req, resp);
		}
        catch(IOException _ex ) {
            System.out.println("ServletCartes doPost KO : IOException : " + _ex);
            req.setAttribute("msgErr" , "ServletCartes doPost KO : IOException : " + _ex);
        }
        catch(ServletException _ex ) {
            System.out.println("ServletCartes doPost KO : ServletException : " + _ex);
            req.setAttribute("msgErr" , "ServletCartes doPost KO : ServletException : " + _ex);
        }
	}	
	
}