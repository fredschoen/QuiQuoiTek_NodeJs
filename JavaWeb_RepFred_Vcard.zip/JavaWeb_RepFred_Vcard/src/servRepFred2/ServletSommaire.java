/* $Id: ServletSommaire.java $ */
package servRepFred2;
/*
 * Servlet de la page "Sommaire"
 * m�thodes: doGet, doPost
 * 
 * @author Fredo
 *
 */

import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import packRepFred2.Outils;

public class ServletSommaire extends HttpServlet {
	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) {
		System.out.println("-----------------------------------------ServletSommaire, doGet");

		// jour
		Date maintenant = new Date();
		String jourDateFormat = DateFormat.getDateInstance(DateFormat.DATE_FIELD).format(maintenant);
		String sAttr_jour = jourDateFormat.substring(0, 6) + "20" + jourDateFormat.substring(6,8);

		// chargement des param�tres de la session
        HttpSession session = req.getSession(true);
        session.setAttribute("sAttr_nomUtil", Outils.nomUtilisateur());
		session.setAttribute("sAttr_jour", sAttr_jour);
		session.setAttribute("sAttr_nomAppli", "R�pertoire");
		session.setAttribute("critTri","AA");
		session.setAttribute("filtreSourceFicVcard","");
		session.setAttribute("filtreNom1","");
	
		// chargement des parametres dans la r�ponse
		req.setAttribute("titreEcran", "Sommaire");
		
		
		//  liens hierarchiques sur une ligne
		req.setAttribute("lgLiensNomNiv1", "rien");

		// trace
		System.out.println("ServletSommaire, fin doGet");
		
		try {				
		req.getRequestDispatcher("jsp/pgSommaire.jsp").forward(req, resp);
		}
		catch(IOException _ex ) {
			System.out.println("Erreur : IOException : " + _ex);
		}
		catch(ServletException _ex ) {
			System.out.println("Erreur : ServletException : " + _ex);
		}
		}

	
	public void doPost(HttpServletRequest req, HttpServletResponse resp) {
		
		System.out.println("-----------------------------------------ServletSommaire doPost");
		
		// chargement des parametres dans la r�ponse
		req.setAttribute("titreEcran",  "Sommaire");
		//  -> lgLiensNomNiv1, 2, 3
		req.setAttribute("lgLiensNomNiv1", "rien");
		
		// trace
		System.out.println("ServletSommaire, fin doPost");
		
		
		try {				
			HttpSession session = req.getSession(false);
			if (session==null) {
				System.out.println("ServletSommaire, (session == null)");
				req.setAttribute("msgErr", "votre session est p�rim�e (timeout)");
				req.getRequestDispatcher("jsp/pgSommaire.jsp").forward(req, resp);
			}
			else {
				req.getRequestDispatcher("jsp/pgSommaire.jsp").forward(req, resp);
			}
		}
		catch(IOException _ex ) {
			System.out.println("Erreur : IOException : " + _ex);
		}
		catch(ServletException _ex ) {
			System.out.println("Erreur : ServletException : " + _ex);
		}
	}
}