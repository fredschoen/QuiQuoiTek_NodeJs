/*
 * Created on 9 janv. 2006
 */
package servRepFred2;
/*
 * servlet de la page "d�tail d'un carte"
 * m�thodes: doGet, doPost
 * 
 * @author Fredo
 *
 */

import packRepFred2.*;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/****************************************************************************************/
public class ServletCarte extends HttpServlet {
    /****************************************************************************************/
    // propos� par Eclipse
    private static final long serialVersionUID = 1L;

    private String operatPg ;
    private String msgErreur;
    private String msgInfo;
	private CarteModel carteModel1;
	private String critTri;
	private String filtreSourceFicVcard;
	private String filtreNom1;
	
	/****************************************************************************************/
	public void doGet(HttpServletRequest req, HttpServletResponse resp) {
		/****************************************************************************************/
		System.out.println("-----------------------------------------ServletCarte doGet, deb");
        System.out.println("ServletCarte, operatPg = <" + req.getParameter("operatPg") + ">");
        System.out.println("ServletCarte, codeIdentPg = <" + req.getParameter("codeIdentPg") + ">");
        System.out.println("ServletCarte, sourceFicVcardPg = <" + req.getParameter("sourceFicVcardPg") + ">");
        System.out.println("ServletCarte, nom1Pg = <" + req.getParameter("nom1Pg") + ">");
        System.out.println("ServletCarte, nom2Pg = <" + req.getParameter("nom2Pg") + ">");
        System.out.println("ServletCarte, nom3Pg = <" + req.getParameter("nom3Pg") + ">");
        System.out.println("ServletCarte, nom4Pg = <" + req.getParameter("nom4Pg") + ">");
        System.out.println("ServletCarte, nom5Pg = <" + req.getParameter("nom5Pg") + ">");
        System.out.println("-----------------------------------------ServletCarte doGet, fin");
		
		;
		//String codeIdentPg = req.getParameter("codeIdentPg");  <- pour Repertoire/DetailCarte?codeIdentPg=PAT001 (non cript�!!)
	}
	
	/****************************************************************************************/
	public void doPost(HttpServletRequest req, HttpServletResponse resp) {
		/****************************************************************************************/	
		try {
			HttpSession session = req.getSession(false);
			if (session==null) {
				System.out.println("ServletSommaire, (session == null)");
				req.setAttribute("msgErr", "votre session est p�rim�e (timeout)");
				req.getRequestDispatcher("jsp/pgSommaire.jsp").forward(req, resp);
			}
			else {
				
                msgErreur=Const.RIEN;
                msgInfo=Const.RIEN;
				
				// trace
				System.out.println("-----------------------------------------ServletCarte doPost");
				
				System.out.println("ServletCarte, operatPg = <" + req.getParameter("operatPg") + ">");
				System.out.println("ServletCarte, codeIdentPg = <" + req.getParameter("codeIdentPg") + ">");
				System.out.println("ServletCarte, sourceFicVcardPg = <" + req.getParameter("sourceFicVcardPg") + ">");
				System.out.println("ServletCarte, nom1Pg = <" + req.getParameter("nom1Pg") + ">");
                System.out.println("ServletCarte, nom2Pg = <" + req.getParameter("nom2Pg") + ">");
                System.out.println("ServletCarte, nom3Pg = <" + req.getParameter("nom3Pg") + ">");
                System.out.println("ServletCarte, nom4Pg = <" + req.getParameter("nom4Pg") + ">");
                System.out.println("ServletCarte, nom5Pg = <" + req.getParameter("nom5Pg") + ">");
				System.out.println("---------fred0");
				System.out.println("critTri="+session.getAttribute("critTri"));
				System.out.println("filtreSourceFicVcard="+session.getAttribute("filtreSourceFicVcard"));
				System.out.println("filtreNom1="+session.getAttribute("filtreNom1"));
				
				// Recuperation de parametres de la requete HTTP
				if (req.getParameter("operatPg")==null){
				    // on est au 1er appel
				    operatPg=Const.SAISIE_CREAT;
				}
				else {
	                operatPg  = req.getParameter("operatPg");
				}
				System.out.println("---------fred1a");

				// Recuperation de parametres de la session
				critTri=session.getAttribute("critTri").toString();
				filtreSourceFicVcard=session.getAttribute("filtreSourceFicVcard").toString();
				filtreNom1=session.getAttribute("filtreNom1").toString();
				
				//  -> lgLiensNomNiv1, 2, 3
				req.setAttribute("lgLiensNomNiv3", Const.RIEN);
				
				System.out.println("ServletCarte, operatPg = <" + operatPg + ">");
				System.out.println("---------fred1b");
				
				
				///////////////////////////////////////////////////////////////////////
				// lire les donn�es de la page re�ue
				///////////////////////////////////////////////////////////////////////
				
				// donn�e toujours disponible: le codeIdentPg Carte
                carteModel1 = new CarteModel();
				carteModel1.codeIdent = req.getParameter("codeIdentPg");
				System.out.println("---------fred1a");
				
				// charger le Model avec les donn�es de la page

			       switch (operatPg) {

			        case Const.ENREG_CREAT:
			        case Const.ENREG_MODIF:

                        System.out.println("ServletCarte, charger carteModel1");
                        carteModel1.sourceFicVcard= req.getParameter("sourceFicVcardPg");
                        carteModel1.nom1=req.getParameter("nom1Pg");
                        carteModel1.nom2=req.getParameter("nom2Pg");
                        carteModel1.nom3=req.getParameter("nom3Pg");
                        carteModel1.nom4=req.getParameter("nom4Pg");
                        carteModel1.nom5=req.getParameter("nom5Pg");
                        carteModel1.telCell=req.getParameter("telCellPg");
                        carteModel1.telHome=req.getParameter("telHomePg");
                        carteModel1.telWork=req.getParameter("telWorkPg");
                        carteModel1.typeAdr=req.getParameter("typeAdrPg");
                        carteModel1.adrBanali1=req.getParameter("adrBanali1Pg");
                        carteModel1.adrBanali2=req.getParameter("adrBanali2Pg");
                        carteModel1.adrBanali3=req.getParameter("adrBanali3Pg");
                        carteModel1.adrBanali4=req.getParameter("adrBanali4Pg");
                        carteModel1.adrBanali5=req.getParameter("adrBanali5Pg");
                        carteModel1.adrBanali6=req.getParameter("adrBanali6Pg");
                        carteModel1.adrBanali7=req.getParameter("adrBanali7Pg");
                        carteModel1.emailHome=req.getParameter("emailHomePg");
                        carteModel1.emailWork=req.getParameter("emailWorkPg");
                        carteModel1.org1=req.getParameter("org1Pg");
                        carteModel1.org2=req.getParameter("org2Pg");
                        carteModel1.title=req.getParameter("titlePg");
                        carteModel1.note=req.getParameter("notePg");
                        carteModel1.fullName=req.getParameter("fullNamePg");

                        carteModel1.afficherDebug("carteModel1");

                        break;

			        case Const.ENREG_SUPPR:
			            //pour lire suiv/preced apr�s suppr
                        System.out.println("ServletCarte, charger carteModel1bb");
                        carteModel1.sourceFicVcard= req.getParameter("sourceFicVcardPg");
                        break;
			        }
				
				///////////////////////////////////////////////////////////////////////
				// traiter la page re�ue
				///////////////////////////////////////////////////////////////////////
				
				traiterRequete();

				///////////////////////////////////////////////////////////////////////
				// envoyer le prochain �cran
				///////////////////////////////////////////////////////////////////////
				
				// chargement des parametres dans la r�ponse

                //operation suivante
                System.out.println("---------fred xxxxx");
                // action
                switch (operatPg) {

                 case Const.SAISIE_CREAT:
                 case Const.SAISIE_MODIF:
                 case Const.SAISIE_SUPPR:
                 case Const.AFFICHAGE:
                     
                     // operatPg inchang� 
                     break;
          
                     // sinon, re passer en modif
                 default:
                     operatPg = Const.SAISIE_MODIF;
                     break;
                }
                System.out.println("---------fred xxxx1 operatPg=" + operatPg);
				
				req.setAttribute("operatPg",  operatPg);
				
				System.out.println("ServletCarte, idem");

				// donn�es de la page
				
				// donn�es au dessus de l'entete
				req.setAttribute("codeIdentPg",carteModel1.codeIdent);
				req.setAttribute("sourceFicVcardPg",Outils.prepareTexteHTML(carteModel1.sourceFicVcard));
                req.setAttribute("nom1Pg",Outils.prepareTexteHTML(carteModel1.nom1));
                req.setAttribute("nom2Pg",Outils.prepareTexteHTML(carteModel1.nom2));
                req.setAttribute("nom3Pg",Outils.prepareTexteHTML(carteModel1.nom3));
                req.setAttribute("nom4Pg",Outils.prepareTexteHTML(carteModel1.nom4));
                req.setAttribute("nom5Pg",Outils.prepareTexteHTML(carteModel1.nom5));
                req.setAttribute("telCellPg",Outils.prepareTexteHTML(carteModel1.telCell));
                req.setAttribute("telHomePg",Outils.prepareTexteHTML(carteModel1.telHome));
                req.setAttribute("telWorkPg",Outils.prepareTexteHTML(carteModel1.telWork));
                req.setAttribute("typeAdrPg",Outils.prepareTexteHTML(carteModel1.typeAdr));
                req.setAttribute("adrBanali1Pg",Outils.prepareTexteHTML(carteModel1.adrBanali1));
                req.setAttribute("adrBanali2Pg",Outils.prepareTexteHTML(carteModel1.adrBanali2));
                req.setAttribute("adrBanali3Pg",Outils.prepareTexteHTML(carteModel1.adrBanali3));
                req.setAttribute("adrBanali4Pg",Outils.prepareTexteHTML(carteModel1.adrBanali4));
                req.setAttribute("adrBanali5Pg",Outils.prepareTexteHTML(carteModel1.adrBanali5));
                req.setAttribute("adrBanali6Pg",Outils.prepareTexteHTML(carteModel1.adrBanali6));
                req.setAttribute("adrBanali7Pg",Outils.prepareTexteHTML(carteModel1.adrBanali7));
                req.setAttribute("emailHomePg",Outils.prepareTexteHTML(carteModel1.emailHome));
                req.setAttribute("emailWorkPg",Outils.prepareTexteHTML(carteModel1.emailWork));
                req.setAttribute("org1Pg",Outils.prepareTexteHTML(carteModel1.org1));
                req.setAttribute("org2Pg",Outils.prepareTexteHTML(carteModel1.org2));
                req.setAttribute("titlePg",Outils.prepareTexteHTML(carteModel1.title));
                req.setAttribute("notePg",Outils.prepareTexteHTML(carteModel1.note));
                req.setAttribute("fullNamePg",Outils.prepareTexteHTML(carteModel1.fullName));
				
				// titre
				req.setAttribute("titreEcran", "D�tail Carte");
				// liens
				req.setAttribute("lgLiensNomNiv1", "sommaire");
				req.setAttribute("lgLiensAdrNiv1"  , "Sommaire");
				req.setAttribute("lgLiensNomNiv2", "liste des Cartes");
				req.setAttribute("lgLiensAdrNiv2"  , "ListeCartes");
				//req.setAttribute("XXX"  , req.getParameter("XXX") );
				
				// msg erreur ou info
                if (msgErreur.equals(Const.RIEN)) {
                    if (!msgInfo.equals(Const.RIEN)) req.setAttribute("msgErr", msgInfo);
                    else req.setAttribute("msgErr", "&nbsp;");
                }
                else {
                    req.setAttribute("msgErr", msgErreur);
                }
				
				
				System.out.println("ServletCarte, avant getRequestDispatcher");
				
				req.getRequestDispatcher("jsp/pgCarte.jsp").forward(req, resp);
				System.out.println("ServletCarte, apr�s forward");
			}
		}
		
		catch(IOException _ex ) {
			System.out.println("Erreur : IOException : " + _ex);
		}
		catch(ServletException _ex ) {
			System.out.println("Erreur : ServletException : " + _ex);
		}
	}

    /****************************************************************************************/
    private void traiterRequete() {
    	/****************************************************************************************/	
        System.out.println("ServletCarte, traiterRequete, carteModel1.codeIdent = <" + carteModel1.codeIdent + ">");

        
       // action
       switch (operatPg) {

        case Const.SAISIE_CREAT:
            // cr�er: RAF
            mettreABlancDonnees();
            break;
 
        case Const.ENREG_CREAT:
        case Const.ENREG_MODIF:
        case Const.ENREG_SUPPR:
            mettreAJourDonnees();
            break;
  
        case Const.SAISIE_MODIF:
        case Const.SAISIE_SUPPR:
        case Const.AFFICHAGE:
        case Const.LECT_SUIV:
        case Const.LECT_PRECED:
            accederDonnees() ;
            break;
        }

       
      // apr�s suppression, lire le SUIV ou PRECED
      switch (operatPg) {

       case Const.ENREG_SUPPR:
           accederDonnees() ;
           break;
       }

       
       System.out.println("ServletCarte, fin traiterRequete");

    }
    
    /*************************************************************************/
    private void mettreABlancDonnees() {
        /* ************************************************************************
         * mettreABlancDonnees
         * ************************************************************************/
        System.out.println("--------- mettreABlancDonnees");
        carteModel1.initCarteModel();
    }
    
    /*************************************************************************/
    private void accederDonnees() {
        /* ************************************************************************
         * accederDonnees
         * ************************************************************************/
        CarteService carteService1 = new CarteService();
        System.out.println("ServletCarte, accederDonnees, deb");
        // action
        switch (operatPg) {

        case Const.AFFICHAGE:
        case Const.SAISIE_MODIF:
        case Const.SAISIE_SUPPR:
            // lire pour affichage page
            carteModel1 = carteService1.lire(carteModel1.codeIdent);
            if (carteService1.erreur.length() >0) {
                msgErreur=carteService1.erreur;        
            } 
            break;

        case Const.LECT_SUIV:
        case Const.LECT_PRECED:
            
            //calcul de la navigation 
            String navig="";
            if (operatPg.contentEquals(Const.LECT_SUIV)) navig=Outils.SUIV;
            else                                   navig=Outils.PRECED;

            //appel 1 
            carteModel1 = carteService1.lireAvecNavigInit(
                     carteModel1.codeIdent, 
                     critTri, 
                     filtreSourceFicVcard, 
                     filtreNom1,
                     navig);
            if (carteService1.erreur.length() >0) {
                msgErreur=carteService1.erreur;        
            } 
             break;

        case Const.ENREG_SUPPR:
            System.out.println("---------fred ENREG_SUPPRaaa");
            // lire pour affichage page
            //essayer le suivant
            carteModel1 = carteService1.lireAvecNavigSuiv(
                    carteModel1.sourceFicVcard, 
                    carteModel1.nom1, 
                    critTri, 
                    filtreSourceFicVcard, 
                    filtreNom1, 
                    Outils.SUIV);
            if (carteService1.erreur.length() >0) {
                System.out.println("---------fred ENREG_SUPPRaaaa");
                //essayer le precedant
                carteModel1 = carteService1.lireAvecNavigSuiv(
                        carteModel1.
                        sourceFicVcard, 
                        carteModel1.nom1, 
                        critTri, 
                        filtreSourceFicVcard, 
                        filtreNom1, 
                        Outils.PRECED);
                if (carteService1.erreur.length() >0) {
                    // si rien trouv�: afficher page vide
                    operatPg=Const.AFFICHAGE;
                    System.out.println("---------fred ENREG_SUPPRaaab");
                }
            }
            break;
            
             
             
         }
        System.out.println("ServletCarte, accederDonnees, fin");
    }
    
    /*************************************************************************/
    private void mettreAJourDonnees() {
        /* ************************************************************************
         * mettreAJourDonnees
         * ************************************************************************/
        CarteService carteService1 = new CarteService();
        System.out.println("ServletCarte, mettreAJourDonnees, deb");

        //donnees OK ?
        switch (operatPg) {
        case Const.ENREG_CREAT:
            System.out.println("---------fredmmdd1");
            // contr�ler, puis modifier l'enregistrement Carte
            if (!carteModel1.donneesCoherentes(CarteModel.CREAT)) {
                msgErreur=carteModel1.erreur;
            }
            break;
        case Const.ENREG_MODIF:
            System.out.println("---------fredmmdd1xx");
            // contr�ler, puis modifier l'enregistrement Carte
            if (!carteModel1.donneesCoherentes(CarteModel.MODIF)) {
                msgErreur=carteModel1.erreur;
            }
            break;
        case Const.ENREG_SUPPR:
            System.out.println("---------fredmmdd1dd");
            // contr�ler, puis modifier l'enregistrement Carte
            if (!carteModel1.donneesCoherentes(CarteModel.SUPPR)) {
                msgErreur=carteModel1.erreur;
            }
            break;
        }
       
        System.out.println("---------mettreAJourDonnees aaa msgErreur=" + msgErreur);

        try {
            
            //nouveau numero
            if  (msgErreur.equals(Const.RIEN) && operatPg.equals(Const.ENREG_CREAT)) {
                   creerNumero();
            }
                
            System.out.println("---------mettreAJourDonnees bbb msgErreur=" + msgErreur);
    
            //enregister 
           if  (msgErreur.equals(Const.RIEN)) {
               System.out.println("---------mettreAJourDonnees xxx" );
    
               switch (operatPg) {
                   case Const.ENREG_CREAT:
                       carteService1.creer(carteModel1);
                       if (carteService1.erreur.length() == 0) {
                           msgInfo= carteModel1.nom1 + " cr��";
                       } 
                       else msgErreur=carteService1.erreur;        
                   break;
               case Const.ENREG_MODIF:
                       carteService1.modifier(carteModel1);
                       
                       if (carteService1.erreur.length() == 0) {
                           msgInfo= carteModel1.nom1 + " modifi�";
                       } 
                       else msgErreur=carteService1.erreur;        
                   break;
               
               case Const.ENREG_SUPPR:
                   carteService1.supprimer(carteModel1);
                   
                   if (carteService1.erreur.length() == 0) {
                       msgInfo= carteModel1.nom1 + " effac�";
                   } 
                   else msgErreur=carteService1.erreur;        
                   break;
               }
           }

       }
       catch(RepFred2Exception _ex) {
           msgErreur=_ex.getMessage();        
       }
       
       finally{
           System.out.println("ServletCarte, mettreAJourDonnees, fin");
           
       }
       
	}

    /****************************************************************************************/
    private void creerNumero() {
        /**************************************************************
         * creerNumero: pour ouvrir page de saisie des info
         * ************************************************************/
        System.out.println("---------fred11");
        
        // pr�parer de la cr�ation: trouver le nouveau num�ro de Carte
        Numerotation numerotation1 = new Numerotation();
        System.out.println("---------fred12");

        String nouveauCode=numerotation1.nouveauCode("Carte");
        
        System.out.println("ServletCarte, creerNumero, nouveauCode= <" + nouveauCode + ">");

        
        if (nouveauCode.equals(Const.RIEN)) {
            msgErreur = "impossible calculer <nouveauCode> ";
        }
        else {
            carteModel1.codeIdent=nouveauCode;
        }
        
    }

}