package servRepFred2;
/*
 * servlet de la page "Aper�u"
 * m�thodes: doGet, doPost
 * 
 * @author Fredo
 *
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

public class ServletApercu extends HttpServlet {
	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) {
		System.out.println("-----------------------------------------ServletApercu, doGet");
		CreerTexteHTML( req,  resp) ;
		System.out.println("-----------------------------------------ServletApercu, fin doGet");
	}

	
	public void doPost(HttpServletRequest req, HttpServletResponse resp) {
		
		System.out.println("-----------------------------------------ServletApercu doPost");
		CreerTexteHTML( req,  resp) ;
		System.out.println("-----------------------------------------ServletApercu fin doPost");
	}
	private void CreerTexteHTML(HttpServletRequest req, HttpServletResponse resp) {
		System.out.println("-----------------------------------------ServletApercu CreerTexteHTML");
	

		try {				
		
		// Initialisation du contexte JNDI et recuperation de la 
		// datasource associ�e � notre application
		Context init = new InitialContext();
		Context ctx = (Context) init.lookup("java:comp/env");
		DataSource ds = (DataSource)ctx.lookup("jdbc/baseRepFred2Rsc");
		System.out.println("---------fred3");
		
		// Recuperation de la connexion a la base de donnees
		Connection con = ds.getConnection();
		System.out.println("---------fred4");
		
		// Creation et execution de la requete
		String select = "SELECT " +
		" carte_sourceFicVcard " +
		", carte_nom1 " +
		", carte_nom2 " +
		" FROM tab_cartes ORDER BY carte_sourceFicVcard ASC , carte_nom1 ASC ;";
		
		
		PreparedStatement pstmt = con.prepareStatement(select);
		
		System.out.println(select);
		
		ResultSet rs = pstmt.executeQuery(select);

		// texte
		String apercuHTML = "<table cellspacing=0 cellpadding=0 align=center border=0>";
				
		// Si on a un resultat
		while (rs.next()) {
			System.out.println("---------fred5"+rs.getString(1)+ rs.getString(2));
			
//            apercuHTML=apercuHTML
//                    +"<tr class=ligneTableau><td>"
//                    +rs.getString(1)
//                    +"</td><td>"
//                    +rs.getString(2)
//                    +"</td><td>"
//                    +rs.getString(3)
//                    +"</td></tr>";
            apercuHTML=apercuHTML
                    +"<tr class=ligneTableau><td width=30% >"
                    +rs.getString(1)
                    +" "
                    +rs.getString(2)
                    +"</td><td width=70%>"
                    +rs.getString(3)
                    +"</td></tr>";
		}		

		apercuHTML=apercuHTML
				+"</table>";
		
		
		// chargement des parametres dans la r�ponse
		req.setAttribute("apercuHTML",apercuHTML);
		req.setAttribute("titreEcran", "Apercu");
		req.setAttribute("lgLiensNomNiv1", "sommaire");
		req.setAttribute("lgLiensAdrNiv1"  , "Sommaire");
		req.setAttribute("lgLiensNomNiv2", "rien");
		// trace
		
		req.getRequestDispatcher("jsp/pgApercu.jsp").forward(req, resp);
		}
		catch(NamingException _ex) {
			System.out.println("Erreur : NamingException : " + _ex);
		}
		catch(SQLException _ex ) {
			System.out.println("Erreur : SQLException : " + _ex);
		}
		catch(IOException _ex ) {
			System.out.println("Erreur : IOException : " + _ex);
		}
		catch(ServletException _ex ) {
			System.out.println("Erreur : ServletException : " + _ex);
		}
		
		System.out.println("-----------------------------------------ServletApercu fin CreerTexteHTMLPost");

	}
}