package packRepFred2;

public final class Const {
    public static final String SAISIE_CREAT = "saisieCreat";
    public static final String SAISIE_MODIF = "saisieModif";
    public static final String SAISIE_SUPPR = "saisieSuppr";
    public static final String ENREG_CREAT  = "enregCreat";
    public static final String ENREG_MODIF  = "enregModif";
    public static final String ENREG_SUPPR  = "enregSuppr";
    public static final String AFFICHAGE    = "affichage";
    public static final String LECT_SUIV    = "lectSuiv";
    public static final String LECT_PRECED  = "lectPreced";
    public static final String RIEN         = "rien";
    // cr��s pour pgDivers
    public static final String CHOIX1       = "choix1";
    public static final String CHOIX2       = "choix2";
    public static final String CHOIX3       = "choix3";
    
    public static final String ID_VCARD4_Adr        ="ADR:";      
    
    public static final String ID_VCARD2_Nom        ="N:";
    public static final String ID_VCARD2_FullName   ="FN:";
    public static final String ID_VCARD2_TelCell    ="TEL;CELL:";
    public static final String ID_VCARD2_TelHome    ="TEL;HOME:";
    public static final String ID_VCARD2_TelPref    ="TEL;PREF:";
    public static final String ID_VCARD2_TelDomicile="TEL;X-Domicile:";
    public static final String ID_VCARD2_TelWork    ="TEL;WORK:";
    public static final String ID_VCARD2_Adr_Debut  ="ADR;";       
    public static final String ID_VCARD2_AdrHome    ="ADR;HOME:";  
    public static final String ID_VCARD2_AdrWork    ="ADR;WORK:";  
    public static final String ID_VCARD2_Org        ="ORG:";
    public static final String ID_VCARD2_Title      ="TITLE:";
    public static final String ID_VCARD2_Note       ="NOTE:";
    public static final String ID_VCARD2_EmailHome  ="EMAIL;HOME:";
    public static final String ID_VCARD2_EmailWork  ="EMAIL;WORK:";
    public static final String ID_VCARD2_EmailInternet="EMAIL;X-INTERNET:";
    public static final String ID_VCARD2_EndVcard   ="END:VCARD";
    public static final String ID_VCARD2_BeginVcard="BEGIN:VCARD";
    public static final String ID_VCARD2_VersionVcard="VERSION:2.1";
    
    
}
