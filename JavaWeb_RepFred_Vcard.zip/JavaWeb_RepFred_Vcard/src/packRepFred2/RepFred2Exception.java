/*
 * mars 2020, fredo
 */
package packRepFred2;

/**********************************************************************
 * outils RepFred2Exception
 * @author Fredo
 **********************************************************************/

/**************************************************************/
public class RepFred2Exception extends Exception {
    /**************************************************************/
    public RepFred2Exception() {
        super();
    }
    public RepFred2Exception(String msgException) {
        super(msgException);
    }
}
