/////////////////////////////////////////////////////////////
package packRepFred2;
/////////////////////////////////////////////////////////////

import java.sql.ResultSet;
import java.sql.SQLException;

public class CarteModel {

    // constantes
    public static final String LECT  = "lect";
    public static final String MODIF = "modif";
    public static final String SUPPR = "suppr";
    public static final String CREAT = "creat";

    public static final String SQL_DEB_SELECT = 
            "SELECT " +
                "carte_codeIdent " +
                ", carte_SourceFicVcard " +
                ", carte_nom1 " +
                ", carte_nom2 " +
                ", carte_nom3 " +
                ", carte_nom4 " +
                ", carte_nom5 " +

                ", carte_TelCell " +
                ", carte_TelHome " +
                ", carte_TelWork " +

                ", carte_TypeAdr " +
                ", carte_AdrBanali1 " +
                ", carte_AdrBanali2 " +
                ", carte_AdrBanali3 " +
                ", carte_AdrBanali4 " +
                ", carte_AdrBanali5 " +
                ", carte_AdrBanali6 " +
                ", carte_AdrBanali7 " +

                ", carte_EmailHome " +
                ", carte_EmailWork " +

                ", carte_Org1 " +
                ", carte_Org2 " +

                ", carte_Title " +
                ", carte_Note " +
                ", carte_FullName " +

                "FROM tab_cartes " 
                ;

    public static final String SQL_DEB_UPDATE = 
            "UPDATE tab_cartes SET " 
                + "  carte_SourceFicVcard = ? " 
                + ", carte_nom1 = ? " 
                + ", carte_nom2 = ? " 
                + ", carte_nom3 = ? " 
                + ", carte_nom4 = ? " 
                + ", carte_nom5 = ? " 
                + ", carte_TelCell = ? " 
                + ", carte_TelHome = ? " 
                + ", carte_TelWork = ? " 
                + ", carte_TypeAdr = ? " 
                + ", carte_AdrBanali1 = ? " 
                + ", carte_AdrBanali2 = ? " 
                + ", carte_AdrBanali3 = ? " 
                + ", carte_AdrBanali4 = ? " 
                + ", carte_AdrBanali5 = ? " 
                + ", carte_AdrBanali6 = ? " 
                + ", carte_AdrBanali7 = ? " 
                + ", carte_EmailHome = ? " 
                + ", carte_EmailWork = ? " 
                + ", carte_Org1 = ? " 
                + ", carte_Org2 = ? " 
                + ", carte_Title = ? " 
                + ", carte_Note = ? "            
                + ", carte_FullName = ? "            
            ;
    public static final String SQL_DEB_INSERT = 
            "INSERT INTO tab_cartes " +
                " (carte_codeIdent " +
                ", carte_SourceFicVcard " +
                ", carte_nom1 " +
                ", carte_nom2 " +
                ", carte_nom3 " +
                ", carte_nom4 " +
                ", carte_nom5 " +
                ", carte_TelCell " +
                ", carte_TelHome " +
                ", carte_TelWork " +
                ", carte_TypeAdr " +
                ", carte_AdrBanali1 " +
                ", carte_AdrBanali2 " +
                ", carte_AdrBanali3 " +
                ", carte_AdrBanali4 " +
                ", carte_AdrBanali5 " +
                ", carte_AdrBanali6 " +
                ", carte_AdrBanali7 " +
                ", carte_EmailHome " +
                ", carte_EmailWork " +
                ", carte_Org1 " +
                ", carte_Org2 " +
                ", carte_Title " +
                ", carte_Note " +
                ", carte_FullName " +
                ") VALUES (" +
                " ? , ? , ? , ? , ? , " +
                " ? , ? , ? , ? , ? , " +
                " ? , ? , ? , ? , ? , " +
                " ? , ? , ? , ? , ? , " +
                " ? , ? , ? , ? , ? " +
                ");"
                ;

    // erreur
    public String erreur="";
    
    //pour charger les champs de chaque carte
    public String codeIdent="";

    public String sourceFicVcard="";
    public String nom1="";
    public String nom2="";
    public String nom3="";
    public String nom4="";
    public String nom5="";

    public String telCell="";
    public String telHome="";
    public String telWork="";

    public String typeAdr="";
    public String adrBanali1="";
    public String adrBanali2="";
    public String adrBanali3="";
    public String adrBanali4="";
    public String adrBanali5="";
    public String adrBanali6="";
    public String adrBanali7="";

    public String emailHome="";
    public String emailWork="";

    public String org1="";
    public String org2="";

    public String title="";
    public String note="";
    public String fullName="";

    public void initCarteModel() {
        codeIdent="";
        sourceFicVcard="";
        nom1="";
        nom2="";
        nom3="";
        nom4="";
        nom5="";
        telCell="";
        telHome="";
        telWork="";
        typeAdr="";
        adrBanali1="";
        adrBanali2="";
        adrBanali3="";
        adrBanali4="";
        adrBanali5="";
        adrBanali6="";
        adrBanali7="";
        emailHome="";
        emailWork="";
        org1="";
        org2="";
        title="";
        note="";
        fullName="";
    }
    
    
    ///////////////////////////////////////////////////////////////
    public boolean donneesCoherentes(String operation ) {
        /////////////////////////////////////////////////////////////
        System.out.println("ContactModel, donneesCoherentes, deb");
        boolean controleOk = true;

        System.out.println(
                "codeIdent=<" + codeIdent + ">" +
                "sourceFicVcard =<" + sourceFicVcard + ">" +
                "nom1=<" + nom1 + 
                "nom2=<" + nom2 + 
                ">" );
        

        // codeIdent
        if (controleOk && !operation.equals(CREAT)) {
            if (codeIdent.length() == 0 ) {
                erreur = "le codeIdent doit �tre renseign�.";
                controleOk=false;
            }
        }
        
        // sourceFicVcard
        if (controleOk && !operation.equals(LECT)
                && !operation.equals(SUPPR)) {
            System.out.println("ContactModel, v�rifier sourceFicVcard");
            if (sourceFicVcard.length() == 0 ) {
                erreur = "le sourceFicVcard doit �tre renseign�";
                controleOk=false;
            }
        }
        
        // nom1
        if (controleOk && !operation.equals(LECT)
                && !operation.equals(SUPPR)) {
            System.out.println("ContactModel, v�rifier nom1");
            if (nom1.length() == 0 ) {
                erreur = "le nom1 doit �tre renseign�";
                controleOk=false;
            }
        }

        //longueur max=100
        if (controleOk && !operation.equals(LECT)
                && !operation.equals(SUPPR)) {
            System.out.println("ContactModel, v�rifier nom1");
            if (nom1.length() >100 
                    || nom1.length() >100 
                    || nom2.length() >100 
                    || nom3.length() >100 
                    || nom4.length() >100 
                    || nom5.length() >100 
                    || telCell.length() >100 
                    || telHome.length() >100 
                    || telWork.length() >100 
                    || typeAdr.length() >100 
                    || adrBanali1.length() >100 
                    || adrBanali2.length() >100 
                    || adrBanali3.length() >100 
                    || adrBanali4.length() >100 
                    || adrBanali5.length() >100 
                    || adrBanali6.length() >100 
                    || adrBanali7.length() >100 
                    || emailHome.length() >100 
                    || emailWork.length() >100 
                    || org1.length() >100 
                    || org2.length() >100 
                    || title.length() >100 
                    || note.length() >100 
                    || fullName.length() >100 
                     
                    ) {
                erreur = "une donn�e fait plus de 100 car. Ne pas d�passer cette taille.";
                controleOk=false;
            }
        }
        
        
        
        System.out.println("ContactModel, donneesCoherentes, erreur=<" + erreur + ">");

        System.out.println("ContactModel, donneesCoherentes, fin");
        
        return controleOk;
    }
    
    
    public void reinitialiserTout() {
        this.nom1="";
        this.nom2="";
        this.nom3="";
        this.nom4="";
        this.nom5="";

        this.telCell="";
        this.telHome="";
        this.telWork="";

        this.typeAdr="";
        this.adrBanali1="";
        this.adrBanali2="";
        this.adrBanali3="";
        this.adrBanali4="";
        this.adrBanali5="";
        this.adrBanali6="";
        this.adrBanali7="";

        this.emailHome="";
        this.emailWork="";

        this.org1="";
        this.org2="";

        this.title="";  
        this.note="";
        this.fullName="";
        
    }


    public void afficherDebug(String nomCarteModel ) {
        System.out.println("==" + nomCarteModel + ".codeIdent=" + this.codeIdent);
        
        System.out.println("==" + nomCarteModel + ".sourceFicVcard=" + this.sourceFicVcard);

        System.out.println("==" + nomCarteModel + ".nom1=" + this.nom1 + nomCarteModel + ".nom2=" + this.nom2);
        System.out.println("==" + nomCarteModel + ".nom3=" + this.nom3 + nomCarteModel + ".nom4=" + this.nom4);
        System.out.println("==" + nomCarteModel + ".nom5=" + this.nom5);

        System.out.println("==" + nomCarteModel + ".telCell=" + this.telCell + nomCarteModel + ".telHome=" + this.telHome);
        System.out.println("==" + nomCarteModel + ".telWork=" + this.telWork);

        System.out.println("==" + nomCarteModel + ".typrAdr   =" + this.typeAdr);
        System.out.println("==" + nomCarteModel + ".adrBanali1=" + this.adrBanali1);
        System.out.println("==" + nomCarteModel + ".adrBanali2=" + this.adrBanali2);
        System.out.println("==" + nomCarteModel + ".adrBanali3=" + this.adrBanali3);
        System.out.println("==" + nomCarteModel + ".adrBanali4=" + this.adrBanali4);
        System.out.println("==" + nomCarteModel + ".adrBanali5=" + this.adrBanali5);
        System.out.println("==" + nomCarteModel + ".adrBanali6=" + this.adrBanali6);
        System.out.println("==" + nomCarteModel + ".adrBanali7=" + this.adrBanali7);

        System.out.println("==" + nomCarteModel + ".emailHome=" + this.emailHome + nomCarteModel + ".emailWork=" + this.emailWork);

        System.out.println("==" + nomCarteModel + ".org1=" + this.org1 + nomCarteModel + ".org2=" + this.org2);

        System.out.println("==" + nomCarteModel + ".title=" + this.title);
        System.out.println("==" + nomCarteModel + ".note="  + this.note);
        System.out.println("==" + nomCarteModel + ".fullName="  + this.fullName);
        
    }

    public void chargerEntete() {
        codeIdent="codeIdent";

        sourceFicVcard="sourceFicVcard";
        nom1="nom1";
        nom2="nom2";
        nom3="nom3";
        nom4="nom4";
        nom5="nom5";

        telCell="telCell";
        telHome="telHome";
        telWork="telWork";

        typeAdr="typeAdr";
        adrBanali1="adrBanali1";
        adrBanali2="adrBanali2";
        adrBanali3="adrBanali3";
        adrBanali4="adrBanali4";
        adrBanali5="adrBanali5";
        adrBanali6="adrBanali6";
        adrBanali7="adrBanali7";

        emailHome="emailHome";
        emailWork="emailWork";

        org1="org1";
        org2="org2";

        title="title";
        note="note";
        note="fullName";
        
    }
    
    
    public void ChargerResultatRequete(ResultSet rs) {
        int i=0;
        try {
            codeIdent=rs.getString(++i);
            sourceFicVcard=rs.getString(++i);
            nom1=rs.getString(++i);
            nom2=rs.getString(++i);
            nom3=rs.getString(++i);
            nom4=rs.getString(++i);
            nom5=rs.getString(++i);

            telCell=rs.getString(++i);
            telHome=rs.getString(++i);
            telWork=rs.getString(++i);

            typeAdr=rs.getString(++i);
            adrBanali1=rs.getString(++i);
            adrBanali2=rs.getString(++i);
            adrBanali3=rs.getString(++i);
            adrBanali4=rs.getString(++i);
            adrBanali5=rs.getString(++i);
            adrBanali6=rs.getString(++i);
            adrBanali7=rs.getString(++i);

            emailHome=rs.getString(++i);
            emailWork=rs.getString(++i);

            org1=rs.getString(++i);
            org2=rs.getString(++i);

            title=rs.getString(++i);
            note=rs.getString(++i);
            fullName=rs.getString(++i);

        }
        catch(SQLException _ex ) {
            System.out.println("Erreur : SQLException : " + _ex);
        }

       return;        
    }
    
    
    
}
