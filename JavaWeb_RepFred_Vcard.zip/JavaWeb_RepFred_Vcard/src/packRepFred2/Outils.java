/*
 * mars 2020, fredo
 */
package packRepFred2;

/**********************************************************************
 * outils divers*
 * m�thodes: nomUtilisateur
 *           ckb, opt, rad: construction objets html
 * @author Fredo
 **********************************************************************/
public class Outils{

	/**
	 * Outils.nomUtilisateur
	 */

    public static String contruireLigneTableauHTML(String nomChampsPg, String valChampsPg, String valOperatPg) {
        System.out.println("Outils, contruireLigneTableauHTML, deb");
        System.out.println("Outils, nomChampsPg=" + nomChampsPg);
        System.out.println("Outils, valChampsPg=" + valChampsPg);
        System.out.println("Outils, valOperatPg=" + valOperatPg);
        String htmlINPUT="";

        // choisir le type d'affichage
        switch (valOperatPg) {
            case Const.SAISIE_SUPPR:
            case Const.AFFICHAGE:
                // affichage simple de la valeur
                htmlINPUT=valChampsPg;
                break;
            default:
                // sinon, saisie possible
                htmlINPUT="<input type='text' name='" + nomChampsPg + "' size='50' value='" + valChampsPg + "'>";
                break;
       }

        System.out.println("Outils, contruireLigneTableauHTML, fin, htmlINPUT=" + htmlINPUT);

        return htmlINPUT;
    }
    
    public static void ctrlCritTri(String critTri) throws RepFred2Exception {

        
        if (critTri.length()>0) {
            char[] tabChar = critTri.toCharArray(); 

            //carte_sourceFicVcard,carte_nom1
            switch (tabChar[0]) {
            case 'A': // carte_sourceFicVcard 
            case 'B': // carte_nom1
                break;
            default: 
                throw new RepFred2Exception("critTri[0] erronne");
            }

            //asc, desc
            switch (tabChar[1]) {
            case 'A':
            case 'D':
                break;
            default: 
                throw new RepFred2Exception("critTri[1] erronne");
            }
            
        }
    }
        
    /**************************************************************/
    public static void ctrlFiltre(String filtre) throws RepFred2Exception {
        /**************************************************************/

        if (filtre.length()>0) {
            char[] tabChar = filtre.toCharArray(); 

            //asc, desc
            switch (tabChar[0]) {
            case '=':
            case '<':
            case '>':
                break;
            default: 
                throw new RepFred2Exception("filtre[0] erronne");
            }

            //carte_sourceFicVcard,souscroupe
            if (filtre.length()==1) {
                throw new RepFred2Exception("filtre[1] vide");
            }
        }
    }
    
    /**************************************************************/
    public static String erreur="";
    public static final String SUIV="suiv";
    public static final String PRECED="preced";
    
    /**************************************************************/
    public static String prepareTexteHTML(String texteBrut) {
        /*************************************************************/
        System.out.println("Outils, prepareTexteHTML deb, texteBrut=" + texteBrut);
        String texteHTML="";
        Outils.erreur="";
        char[] tabChar = texteBrut.toCharArray(); 
        for (int i = 0; i < tabChar.length; i++) { 
            switch (tabChar[i]) {
            case '\'':
                texteHTML=texteHTML+ "&apos;"; 
                break;
            case '\"':
                texteHTML=texteHTML+ "&quot;"; 
                break;
            default: 
                texteHTML=texteHTML+ tabChar[i]; 
                break;
            }
        }
        System.out.println("Outils, prepareTexteHTML fin, texteHTML=" + texteHTML);
        return texteHTML;
    }

    /**************************************************************/
    public static String prepareTexteSQL(String texteBrut) {
        /*************************************************************/
        System.out.println("Outils, prepareTexteSQL deb, texteBrut=" + texteBrut);
        String texteHTML="";
        Outils.erreur="";
        char[] tabChar = texteBrut.toCharArray(); 
        for (int i = 0; i < tabChar.length; i++) { 
            switch (tabChar[i]) {
            case '\'':
                texteHTML=texteHTML + "'" + "'"; 
                break;
            default: 
                texteHTML=texteHTML+ tabChar[i]; 
                break;
            }
        }
        System.out.println("Outils, prepareTexteSQL fin, texteHTML=" + texteHTML);
        return texteHTML;
    }
    /**************************************************************/
    public static String nomUtilisateur() {
        /**************************************************************/
        String s="fredo";
        Outils.erreur="";
        
        System.out.println("Outils.nomUtilisateur, s=[" + s + "]");
        
        return s;
    }

	/**************************************************************/
    public static String txtWherePourListe(String filtreSourceFicVcard, String filtreNom1) {
		/**************************************************************/
		System.out.println("Outils, txtWherePourListe, deb " 
				+ " filtreSourceFicVcard=<" + filtreSourceFicVcard + ">"
				+ " filtreNom1=<" + filtreNom1 + ">"
		);

		String strReturn="";
		Outils.erreur="";
		
		try {
	        ctrlFiltre(filtreSourceFicVcard);
	        ctrlFiltre(filtreNom1);
		    // filtre sur carte_sourceFicVcard
	        if (filtreSourceFicVcard.length()>0) {
	            String filtreSourceFicVcardSQL=prepareTexteSQL(filtreSourceFicVcard.substring(1));
	            switch (filtreSourceFicVcard.substring(0, 1)) {
	            case "=":
	                strReturn=" WHERE carte_sourceFicVcard like '" + filtreSourceFicVcardSQL + "%'";
	                break;
	            case "<":
	                strReturn=" WHERE carte_sourceFicVcard < '" + filtreSourceFicVcardSQL + "'";
	                break;
	            case ">":
	                strReturn=" WHERE carte_sourceFicVcard > '" + filtreSourceFicVcardSQL + "'";
	                break;
	            default:
	                System.out.println("Outils, txtWherePourListe, " 
	                        + " filtreSourceFicVcard erron�" + filtreSourceFicVcard + ">"
	                );
	                erreur="filtreSourceFicVcard erron�=" + filtreSourceFicVcard + "";
	                break;
	            }
	        }
	        
	        System.out.println("Outils, txtWherePourListe, apr�s Source " 
	                + " strReturn=<" + strReturn + ">"
	                );

	        
	        // filtre sur carte_nom1
	        if (filtreNom1.length()>0) {
	            if (strReturn.length()>0) {
	                strReturn = strReturn + " AND ";
	            } else {
	                strReturn = " WHERE ";
	            }
	            switch (filtreNom1.substring(0, 1)) {
	            case "=":
	                strReturn = strReturn + " carte_nom1 like '" + filtreNom1.substring(1) + "%'";
	                break;
	            case "<":
	                strReturn = strReturn + " carte_nom1 < '" + filtreNom1.substring(1) + "'";
	                break;
	            case ">":
	                strReturn = strReturn + " carte_nom1 > '" + filtreNom1.substring(1) + "'";
	                break;
	            default:
	                System.out.println("Outils, txtWherePourListe, " 
	                        + " filtreNom1 erron�" + filtreNom1 + ">"
	                );
	                erreur="filtreNom1 erron�=" + filtreNom1 + "";
	                break;
	            }
	        }
	        
	        System.out.println("Outils, txtWherePourListe, fin " 
	                + " strReturn=<" + strReturn + ">"
	        );
		}
        catch (RepFred2Exception e){
            erreur=e.getMessage();
        }
		finally {
        }
        System.out.println("---------Outils.erreur=" + Outils.erreur);
        System.out.println("Outils.txtWherePourListe, return, erreur=" 
                + erreur);
        return strReturn;
	}
	
	/**************************************************************/
	public static String txtWhereBornes(String critTri, String valSourceFicVcard, String valNom1, String valCodeIdent) {
		/**************************************************************/
		System.out.println("Outils, txtWhereBornes : "
				+ ", critTri =<" + critTri   + ">"
				+ ", valSourceFicVcard =<" + valSourceFicVcard     + ">"
				+ ", valNom1 =<" + valNom1     + ">"
                + ", valCodeIdent =<" + valCodeIdent   + ">"
				);
        String    strReturn = "";
        Outils.erreur="";

		try {
    		ctrlCritTri(critTri);
    		
    		// operateur dans le WHERE
    		String operWhere = "";
    	    String ordre=critTri.substring(1,2);
            System.out.println("Outils, txtWhereBornes : ordre =<" + ordre + ">");
    
    		if        (ordre.equals("A")) {
    		    operWhere=">";
            } else {
                operWhere="<";
            } 
    		
            System.out.println("Outils.txtWhereBornes, operWhere    =<" + operWhere     + ">");
    		
    		strReturn =             " (";
    		strReturn = strReturn + "   (";
    		strReturn = strReturn + "     carte_sourceFicVcard  = " + "'"+ valSourceFicVcard + "'";
    		strReturn = strReturn + "     AND carte_nom1 " + operWhere + " '" + valNom1 + "'";
    		strReturn = strReturn + "   )";
    		strReturn = strReturn + " OR carte_sourceFicVcard " + operWhere + " '"+ valSourceFicVcard + "'";
    		strReturn = strReturn + " )";
		}
        catch (RepFred2Exception e){
            System.out.println("Outils.txtWhereBornes, RepFred2Exception erreur=" 
                    + erreur);
            erreur=e.getMessage();
        }
        finally {
            System.out.println("Outils.txtWhereBornes, finally ");
        }
        //retour
        return strReturn;
	}

	/**************************************************************/
	public static String txtOrderBy(String critTri) {
		/**************************************************************/
		System.out.println("Outils.txtOrderBy, critTri    =<" + critTri     + ">");
		String strReturn="";
        Outils.erreur="";
		String ordre=" ASC "; // ASC par d�faut

		// ordres de tri
		if (critTri.substring(1,2).equals("D")) ordre=" DESC ";
        System.out.println("Outils.txtOrderBy, ordre  =<" + ordre + ">");
		
		// critere de tri
		String critere=critTri.substring(0,1);
		System.out.println("Outils.txtOrderBy, critere=<" + critere + ">");
		switch (critere) {
		case "B":
			strReturn = strReturn + " ORDER BY carte_nom1"   + ordre;
			break;
		case "C":
			strReturn = strReturn + " ORDER BY carte_nom2"  + ordre; 
			break;
		default: // "A" <=> carte_sourceFicVcard + carte_nom1
			strReturn = strReturn + " ORDER BY carte_sourceFicVcard" + ordre + ", carte_nom1" + ordre; 
			break;
		}
		
		// codeIdent pour le cas d'un doublon sur carte_sourceFicVcard+carte_nom1
		strReturn = strReturn + " , carte_codeIdent" + ordre;
		
		//retour
		return strReturn;
	}

}
