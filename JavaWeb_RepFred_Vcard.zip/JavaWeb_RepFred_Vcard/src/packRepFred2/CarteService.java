/**
 * 
 *  Actions sur l'enregistrement d'un Carte
 *  M�thodes: lire, modifier, creer
 * 
 * @author Fredo
 *
 */

package packRepFred2;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/////////////////////////////////////////////////////////////
public class CarteService {
	/////////////////////////////////////////////////////////////
	
	public String erreur;
	
	public CarteService() {
		erreur="";
	}
	
	/////////////////////////////////////////////////////////////
	public CarteModel lire (String carte_codeIdent) {
		/////////////////////////////////////////////////////////////
		CarteModel carteModel1 = new CarteModel();
		System.out.println("CarteService, lire, carte_codeIdent=<" + carte_codeIdent + ">");
		
		try {
			System.out.println("CarteService, try Context");
			// Initialisation du contexte JNDI et recuperation de la datasource associ�e � l'application
			Context init = new InitialContext();
			Context ctx = (Context) init.lookup("java:comp/env");
			DataSource ds = (DataSource)ctx.lookup("jdbc/baseRepFred2Rsc");
			
			// Recuperation de la connexion a la base de donnees
			Connection con = ds.getConnection();
			
			String requete = CarteModel.SQL_DEB_SELECT +
					"WHERE carte_codeIdent ='" + carte_codeIdent + "';";

			System.out.println(requete);
			
			PreparedStatement pstmt = con.prepareStatement(requete);
			
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next()) {
			    carteModel1.ChargerResultatRequete(rs);
			}
			else {
				erreur="codeIdent Carte " + carteModel1.codeIdent + "non trouv�";
				System.out.println(erreur);
			}
			rs.close();
			con.close();
			ctx.close();
			init.close();
		}
		catch(SQLException _ex ) {
			System.out.println("Erreur : SQLException : " + _ex);
		}
		catch(NamingException _ex) {
			System.out.println("Erreur : NamingException : " + _ex);
		}
		return carteModel1;
	}

	/////////////////////////////////////////////////////////////
	public CarteModel lireAvecNavigInit (
			String carte_codeIdent, 
			String critTri,  
			String filtreSourceFicVcard,  
			String filtreNom1, 
			String navig) {
		/////////////////////////////////////////////////////////////
		System.out.println("CarteService, lireAvecNavigInit (carte_codeIdent), deb: " 
				+ " carte_codeIdent=<" + carte_codeIdent + ">"
				+ " critTri=<" + critTri + ">"
				+ " filtreSourceFicVcard=<" + filtreSourceFicVcard + ">"
                + " filtreNom1=<" + filtreNom1 + ">"
                + " navig=<" + navig + ">"
		);

	    CarteModel carteModel1 = new CarteModel();
        CarteModel carteModel2 = new CarteModel();

		String requete="";
        String critTriNavig="";
        int    i=0;

        // si preced, inverser l'ordre de tri
        if (navig.equals(Outils.SUIV)) {
            // ordre inchang�
            critTriNavig=critTri;
        } else {
            // invertion 
            if (critTri.substring(1,2).equals("D")) {
                
                critTriNavig = critTri.substring(0,1)+"A";
            }
            else {
                critTriNavig = critTri.substring(0,1)+"D";
            }
        }
        System.out.println("CarteService, critTriNavig<" + critTriNavig +">" );
        
		// suite
		try {
			System.out.println("CarteService, try Context");
			// Initialisation du contexte JNDI et recuperation de la datasource associ�e � l'application
			Context init = new InitialContext();
			Context ctx = (Context) init.lookup("java:comp/env");
			DataSource ds = (DataSource)ctx.lookup("jdbc/baseRepFred2Rsc");
			
			// Recuperation de la connexion a la base de donnees
			Connection con = ds.getConnection();
			
            // lire la ligne en cours (pour m�moire)
            requete = CarteModel.SQL_DEB_SELECT
                    + "WHERE carte_codeIdent ='" + carte_codeIdent + "';";

            System.out.println(requete);
            
            PreparedStatement pstmt = con.prepareStatement(requete);
            ResultSet rs = pstmt.executeQuery();
            
            if(rs.next()) {
                carteModel1.ChargerResultatRequete(rs);
                // Sauver le r�sultat (pour le restituer si fin atteinte)
                carteModel2=carteModel1;
            }
            else {
                erreur="carte_codeIdent " + carte_codeIdent + "non trouv�";
                System.out.println(erreur);
            }
			
            // lire la ligne suivante/pr�c�dente
			requete = CarteModel.SQL_DEB_SELECT;
			
			// filtre sur carte_SourceFicVcard
			String whereLike=Outils.txtWherePourListe(filtreSourceFicVcard, filtreNom1);
			if (!whereLike.contentEquals("")) {
		        System.out.println("CarteService, whereLike<" + whereLike + '>' ); 
			    requete=requete + whereLike + " AND ";
			}
			else {
                System.out.println("CarteService, pas de whereLike" ); 
                requete=requete + " WHERE ";			    
			}
			
			// bornes de d�but
			requete=requete+Outils.txtWhereBornes(
			        critTriNavig,
			        carteModel1.sourceFicVcard, 
			        carteModel1.nom1, 
			        carteModel1.codeIdent);
			
            //assemblage
			requete=requete+Outils.txtOrderBy(critTriNavig);
			requete=requete+";";

			System.out.println(requete);
			
			
			// requete
			pstmt = con.prepareStatement(requete);
			rs    = pstmt.executeQuery();
			
			// lire l'enreg en cours
			if(rs.next()) {
                carteModel1.ChargerResultatRequete(rs);
			}
			else {
				erreur="fin de liste atteinte";
				//rappel de l'enreg en cours
				carteModel1=carteModel1;
				System.out.println(erreur);
			}
			rs.close();
			con.close();
			ctx.close();
			init.close();
		}
		catch(SQLException _ex ) {
			System.out.println("Erreur : SQLException : " + _ex);
        //TODO: transmettre l'erreur + la g�rer dans l'appelant			
		}
		catch(NamingException _ex) {
			System.out.println("Erreur : NamingException : " + _ex);
		}
  		return carteModel1;
	}
	
    /////////////////////////////////////////////////////////////
    public CarteModel lireAvecNavigSuiv (
            String carte_SourceFicVcard, 
            String carte_nom1,
            String critTri,  
            String filtreSourceFicVcard,  
            String filtreNom1, 
            String navig) {
        /////////////////////////////////////////////////////////////
        CarteModel carteModel1 = new CarteModel();
        CarteModel carteModel2 = new CarteModel();
        System.out.println("CarteService, lireAvecNavigSuiv (carte_SourceFicVcard+carte_nom1), deb:" 
                + " carte_SourceFicVcard=<" + carte_SourceFicVcard + ">"
                + " carte_nom1=<" + carte_nom1 + ">"
                + " critTri=<" + critTri + ">"
                + " filtreSourceFicVcard=<" + filtreSourceFicVcard + ">"
                + " filtreNom1=<" + filtreNom1 + ">"
                + " navig=<" + navig + ">"
        );
        
        String requete="";
        String critTriNavig="";

        // si preced, inverser l'ordre de tri
        if (navig.equals(Outils.SUIV)) {
            // ordre inchang�
            critTriNavig=critTri;
        } else {
            // inversion 
            if (critTri.substring(1,2).equals("D")) {
                
                critTriNavig = critTri.substring(0,1)+"A";
            }
            else {
                critTriNavig = critTri.substring(0,1)+"D";
            }
        }
        System.out.println("CarteService, critTriNavig<" + critTriNavig +">" );
        
        // suite
        try {
            System.out.println("CarteService, try Context");
            // Initialisation du contexte JNDI et recuperation de la datasource associ�e � l'application
            Context init = new InitialContext();
            Context ctx = (Context) init.lookup("java:comp/env");
            DataSource ds = (DataSource)ctx.lookup("jdbc/baseRepFred2Rsc");
            
            // declaration
            ResultSet rs;
            String carte_codeIdent="";
            
            // lire la ligne suivante/pr�c�dente (seuls les champs cl� sont n�cessaires)
            requete = CarteModel.SQL_DEB_SELECT; 
            // filtre sur carte_SourceFicVcard
            String whereLike=Outils.txtWherePourListe(filtreSourceFicVcard, filtreNom1);
            if (!whereLike.contentEquals("")) {
                System.out.println("CarteService, whereLike<" + whereLike + '>' ); 
                requete=requete + whereLike + " AND ";
            }
            else {
                System.out.println("CarteService, pas de whereLike" ); 
                requete=requete + " WHERE ";                
            }
            
            // bornes de d�but
            requete=requete+Outils.txtWhereBornes(critTriNavig,carte_SourceFicVcard, carte_nom1, carte_codeIdent);
            
            //assemblage
            requete=requete+Outils.txtOrderBy(critTriNavig);
            requete=requete+";";

            System.out.println(requete);
                        
            // requete
            // Recuperation de la connexion a la base de donnees
            Connection con = ds.getConnection();
            PreparedStatement pstmt = con.prepareStatement(requete);
            
            pstmt = con.prepareStatement(requete);
            rs    = pstmt.executeQuery();
            
            // lire l'enreg en cours
            if(rs.next()) {
                carteModel1.ChargerResultatRequete(rs);
            }
            else {
                erreur="fin de liste atteinte";
                //rappel de l'enreg en cours
                carteModel1.codeIdent=carte_codeIdent;
                carteModel1.sourceFicVcard=carte_SourceFicVcard;
                carteModel1.nom1=carte_nom1;
                //TODO: r�cup�rer le dernier enreg lu. mais on n'a pas le codeIdent !!!!
                System.out.println(erreur);
            }
            rs.close();
            con.close();
            ctx.close();
            init.close();
        }
        catch(SQLException _ex ) {
            System.out.println("Erreur : SQLException : " + _ex);
        }
        catch(NamingException _ex) {
            System.out.println("Erreur : NamingException : " + _ex);
        }
        return carteModel1;
    }
    
    /////////////////////////////////////////////////////////////
	public boolean creer (CarteModel carteModel1) {
		/////////////////////////////////////////////////////////////
		boolean b=true;
		System.out.println("CarteService, creer");
		
		try {
			System.out.println("CarteService, try Context");
			// Initialisation du contexte JNDI et recuperation de la datasource associ�e � l'application
			Context init = new InitialContext();
			Context ctx = (Context) init.lookup("java:comp/env");
			DataSource ds = (DataSource)ctx.lookup("jdbc/baseRepFred2Rsc");
			
			// Recuperation de la connexion a la base de donnees
			Connection con = ds.getConnection();
			
			String requete =  CarteModel.SQL_DEB_INSERT
			;
			System.out.println(requete);
			
			int i=0;
			PreparedStatement pstmt = con.prepareStatement(requete);
			pstmt.setString(++i, carteModel1.codeIdent);
			pstmt.setString(++i, carteModel1.sourceFicVcard);
			pstmt.setString(++i, carteModel1.nom1);
			pstmt.setString(++i, carteModel1.nom2);
            pstmt.setString(++i, carteModel1.nom3);
            pstmt.setString(++i, carteModel1.nom4);
            pstmt.setString(++i, carteModel1.nom5);
            pstmt.setString(++i, carteModel1.telCell);
            pstmt.setString(++i, carteModel1.telHome);
            pstmt.setString(++i, carteModel1.telWork);
            pstmt.setString(++i, carteModel1.typeAdr);
            pstmt.setString(++i, carteModel1.adrBanali1);
            pstmt.setString(++i, carteModel1.adrBanali2);
            pstmt.setString(++i, carteModel1.adrBanali3);
            pstmt.setString(++i, carteModel1.adrBanali4);
            pstmt.setString(++i, carteModel1.adrBanali5);
            pstmt.setString(++i, carteModel1.adrBanali6);
            pstmt.setString(++i, carteModel1.adrBanali7);
            pstmt.setString(++i, carteModel1.emailHome);
            pstmt.setString(++i, carteModel1.emailWork);
            pstmt.setString(++i, carteModel1.org1);
            pstmt.setString(++i, carteModel1.org2);
            pstmt.setString(++i, carteModel1.title);
            pstmt.setString(++i, carteModel1.note);
            pstmt.setString(++i, carteModel1.fullName);
			
			int nnmaj = pstmt.executeUpdate();	
			System.out.println("CarteModel,  INSERT ok");
			
			con.close();
			ctx.close();
			init.close();
			
		}
		
		catch(SQLException _ex ) {
			System.out.println("Erreur : SQLException : " + _ex);
		}
		catch(NamingException _ex) {
			System.out.println("Erreur : NamingException : " + _ex);
		}
		return b;
	}

    
    /////////////////////////////////////////////////////////////
    public boolean modifier (CarteModel carteModel1) throws RepFred2Exception{
        /////////////////////////////////////////////////////////////
        boolean b=true;
        System.out.println("CarteService, modifier, carteModel1.codeIdent=<" + carteModel1.codeIdent + ">");
        
        try {
            System.out.println("CarteService, try Context");
            // Initialisation du contexte JNDI et recuperation de la datasource associ�e � l'application
            Context init = new InitialContext();
            Context ctx = (Context) init.lookup("java:comp/env");
            DataSource ds = (DataSource)ctx.lookup("jdbc/baseRepFred2Rsc");
            
            // Recuperation de la connexion a la base de donnees
            Connection con = ds.getConnection();
            
            String requete="";
            
            // texte de la requete
                requete = CarteModel.SQL_DEB_UPDATE 
                    + " WHERE carte_codeIdent ='" + carteModel1.codeIdent + "';";

            // pr�paration de la requete
            System.out.println(requete);
            PreparedStatement pstmt = con.prepareStatement(requete);
            int i=0;
            
            // donn�es de la requete
            pstmt.setString(++i, carteModel1.sourceFicVcard);
            pstmt.setString(++i, carteModel1.nom1);
            pstmt.setString(++i, carteModel1.nom2);
            pstmt.setString(++i, carteModel1.nom3);
            pstmt.setString(++i, carteModel1.nom4);
            pstmt.setString(++i, carteModel1.nom5);
            pstmt.setString(++i, carteModel1.telCell);
            pstmt.setString(++i, carteModel1.telHome);
            pstmt.setString(++i, carteModel1.telWork);
            pstmt.setString(++i, carteModel1.typeAdr);
            pstmt.setString(++i, carteModel1.adrBanali1);
            pstmt.setString(++i, carteModel1.adrBanali2);
            pstmt.setString(++i, carteModel1.adrBanali3);
            pstmt.setString(++i, carteModel1.adrBanali4);
            pstmt.setString(++i, carteModel1.adrBanali5);
            pstmt.setString(++i, carteModel1.adrBanali6);
            pstmt.setString(++i, carteModel1.adrBanali7);
            pstmt.setString(++i, carteModel1.emailHome);
            pstmt.setString(++i, carteModel1.emailWork);
            pstmt.setString(++i, carteModel1.org1);
            pstmt.setString(++i, carteModel1.org2);
            pstmt.setString(++i, carteModel1.title);
            pstmt.setString(++i, carteModel1.note);
            pstmt.setString(++i, carteModel1.fullName);
            
            // execution de la requete
            int nnmaj = pstmt.executeUpdate();  
            
            con.close();
            ctx.close();
            init.close();
            
        }
        
        catch(SQLException _ex ) {
            String txt="SQLException : " + _ex.getErrorCode() + " // " + _ex.getMessage();
            System.out.println(txt);
            throw new RepFred2Exception(txt);
        }
        catch(NamingException _ex) {
            String txt="NamingException : " + _ex.getMessage() ;
            System.out.println(txt);
            // "Le Contexte est en lecture seule" : pas grave -> pas de "throw new RepFred2Exception(txt);�
        }
        return b;
    }
    
    
    /////////////////////////////////////////////////////////////
    public boolean supprimer (CarteModel carteModel1) {
        /////////////////////////////////////////////////////////////
        boolean b=true;
        System.out.println("CarteService, supprimer, carteModel1.codeIdent=<" + carteModel1.codeIdent + ">");
        
        try {
            System.out.println("CarteService, try Context");
            // Initialisation du contexte JNDI et recuperation de la datasource associ�e � l'application
            Context init = new InitialContext();
            Context ctx = (Context) init.lookup("java:comp/env");
            DataSource ds = (DataSource)ctx.lookup("jdbc/baseRepFred2Rsc");
            
            // Recuperation de la connexion a la base de donnees
            Connection con = ds.getConnection();
            
            String requete="";
            
            // texte de la requete
                requete = "DELETE FROM tab_cartes " 
                    + " WHERE carte_codeIdent ='" + carteModel1.codeIdent + "';";

            // pr�paration de la requete
            System.out.println(requete);
            PreparedStatement pstmt = con.prepareStatement(requete);
            int i=0;
            
            // execution de la requete
            int nnmaj = pstmt.executeUpdate();  
            System.out.println("CarteModel,  Update");
            
            con.close();
            ctx.close();
            init.close();
            
        }
        
        catch(SQLException _ex ) {
            System.out.println("Erreur : SQLException : " + _ex);
        }
        catch(NamingException _ex) {
            System.out.println("Erreur : NamingException : " + _ex);
        }
        return b;
    }
    


}
