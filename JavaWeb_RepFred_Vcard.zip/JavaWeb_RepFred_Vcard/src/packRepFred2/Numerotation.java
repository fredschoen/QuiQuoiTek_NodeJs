/*
  * Created on 18 janv. 2006
 *
 */
package packRepFred2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * 
 * incr�menter des num�ros
 * li� � la table "num�ros"
 * m�thodes: nouveauCode
 * 			entr�e: type de num�ro
 * 			sortie: nouveau num�ro utilisable pour insertion en table
 * 
 * @author Fredo
 *
 */
public class Numerotation {
	
		public String nouveauCode(String typeNumero) {
        System.out.println("Numerotation, nouveauCode debut");
		String nouveauCode_="rien";
		Integer nouveauNumero=0;
		
		try {
			System.out.println("Numerotation, try Context");
			// Initialisation du contexte JNDI et recuperation de la datasource associ�e � l'application
			Context init = new InitialContext();
			Context ctx = (Context) init.lookup("java:comp/env");
			DataSource ds = (DataSource)ctx.lookup("jdbc/baseRepFred2Rsc");
			
			// Recuperation de la connexion a la base de donnees
			Connection con = ds.getConnection();
			
			String requete = "SELECT num_dernier FROM tab_numeros where num_type = '" + typeNumero + "';" ;
			PreparedStatement pstmt = con.prepareStatement(requete);
			System.out.println(requete);
			ResultSet rs = pstmt.executeQuery(requete);
			
			if(rs.next()) {
				if (rs.getString(1) == null) {
					System.out.println("typCode=" + typeNumero + " num_dernier KO !!!");
				}
				else {
					nouveauNumero   = rs.getInt(1) + 1;
                    nouveauCode_   = typeNumero + nouveauNumero;
					
					System.out.println("nouveauCode_=" + nouveauCode_);

					String requete2 = "update numeros set num_dernier = " + nouveauNumero + "  where num_type = '" + typeNumero + "';";
                    System.out.println(requete2);

                    PreparedStatement pstmt2 = con.prepareStatement(requete2);
					int nnmaj = pstmt.executeUpdate(requete2);	
					System.out.println("Numerotation,  Update OK");
				}
			}
			else {
				System.out.println("typeNumero " + typeNumero + " non trouv� (Num)");
			}
			con.close();
			ctx.close();
			init.close();
		}
		
		catch(SQLException _ex ) {
			System.out.println("Erreur : SQLException : " + _ex);
		}
		catch(NamingException _ex) {
			System.out.println("Erreur : NamingException : " + _ex);
		}
		
        System.out.println("Numerotation, nouveauCode fin, nouveauCode_ = " + nouveauCode_);
		return nouveauCode_;
	}
	
}
