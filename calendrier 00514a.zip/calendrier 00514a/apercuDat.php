<?php
include("entetePHP.inc"); 
$mysqli =  new mysqli('localhost', 'admin', 'fred', "calendrier");
if ($mysqli->connect_errno) {
	echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
$res = $mysqli->query("select cod, grp, sgr, dat, inf from evenements ORDER BY dat DESC");
?>
<html>
<link href="ressource/css.css" type=text/css  rel=stylesheet>
<body>

<table cellSpacing=1 cellPadding=1 width="650" align=center border=0 >
	<?php
	$annPrev="0001";
	while ($row = $res->fetch_assoc()) {
	?>
		<tr class=ligne>
		<td width="15%" ALIGN=RIGHT>


		<?php 
				$datAff=$row['dat'];
				$annAff=substr($datAff,0,4);
				//echo "[".$annAff . ";".$annPrev."]";
				if ($annAff==$annPrev) {
					//echo " (idem)";
					$datAff=substr($datAff,5,5);
				}
				else {
					//echo " (differ)";
				}
				echo $datAff; 
		?></td>
		<td width="15%"><?php echo $row['grp']; ?></td>
		<td width="15%"><?php echo $row['sgr']; ?></td>
		<td width="55%"><?php echo $row['inf']; ?></td>
		</tr>	
		<?php
			$annPrev=$annAff;
		}
	/* Libération du jeu de résultats */
	$res->close();
	?>
</table>
</body>