<?php
include("entetePHP.inc"); 
$NomPage="validation modification événement";
$NomPgRetour="liste";
$NomPgSuite="";
$msg="";
$mysqli =  new mysqli('localhost', 'admin', 'fred', "calendrier");
if ($mysqli->connect_errno) {
	echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
$req="UPDATE evenements SET "
. ' dat = ' 
. "'" . $_POST['dat'] . "'" .  ', ' 
. ' grp = ' 
. "'" . $_POST['grp'] . "'" .  ', ' 
. ' sgr = ' 
. "'" . $_POST['sgr'] . "'" .  ', ' 
. ' inf = ' 
. "'" . $_POST['inf'] . "'" 
. " WHERE cod = '" . $_POST['cod'] . "'"
;
$msg="modification de l'enreg "
.  $_POST['dat'] . "," 
.  $_POST['grp'] . "," 
.  $_POST['sgr'] . ":<br>" ;

if ($mysqli->query($req)) {
	$msg=$msg ."base de données mise à jour";
}
else
{
	$msg=$msg . "echec modification: (" . $mysqli->errno . ") " 
	 . "<br>" . "$req: " . $req;	
}
/* Libération du jeu de résultats */
$mysqli->close();

$_SESSION['msg'] = $msg;
echo $msg;
header('Location: liste.php');
exit();
