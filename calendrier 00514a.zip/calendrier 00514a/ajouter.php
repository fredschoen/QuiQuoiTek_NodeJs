<?php 
include("entetePHP.inc"); 
$NomPage="ajouter un événement";
$NomPgRetour="liste";
$NomPgSuite="validCreat";
$Msg="";
?>
<html>
<head>
<?php include("enteteHTML.inc"); ?>
</head>
<body>
<?php include("hautPage.inc"); ?>

<form name='formulairePg' action="" method="post">

<table cellSpacing=0 cellPadding=4 width="650" align=center border=0>  	

  <tr class=ligne>
  	<td> dat </td>
  	<td><input type="text" name="dat" size="50" value=""> </td>
  </tr>

  <tr class=ligne>
  	<td> grp </td>
  	<td><input type="text" name="grp" size="50" value=""> </td>
  </tr>

  <tr class=ligne>
  	<td> sgr </td>
  	<td><input type="text" name="sgr" size="50" value=""> </td>
  </tr>

  <tr class=ligne>
  	<td> inf </td>
  	<td><input type="text" name="inf" size="50" value=""> </td>
  </tr>
</table>
<?php include("basPage.inc"); ?>

</form>
</body>
</html>