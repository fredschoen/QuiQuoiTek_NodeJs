<?php
date_default_timezone_set('Europe/Paris');

$script_timezone = date_default_timezone_get();

if (strcmp($script_timezone, ini_get('date.timezone'))){
    echo 'Le décalage horaire du script diffère du décalage horaire défini dans le fichier ini.';
} else {
    echo 'Le décalage horaire du script est équivalent à celui défini dans le fichier ini.';
}
?>
