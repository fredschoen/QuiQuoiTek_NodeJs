<?php
  // Definition des constantes et variables
  define('NOM_APPLI','CalendFred');
  define('TRI','ga');
  define('LOGIN','');
  $errorMessage = '';
 
  // Test de l'envoi du formulaire
  if(!empty($_POST)) 
  {
    // Les identifiants sont transmis ?
    if(!empty($_POST['login'])) 
    {
      // Sont-ils les mêmes que les constantes ?
      if($_POST['login'] === LOGIN) 
      {
        $errorMessage = 'Mauvais login !';
      }
        else
      {
        // On ouvre la session
        session_start();
        // On enregistre le login en session
        $_SESSION['login'] = $_POST['login'];
        $_SESSION['nomAppli'] = NOM_APPLI;
        $_SESSION['tri'] = TRI;
        $_SESSION['fltrDat'] = '';
        $_SESSION['fltrGrp'] = '';
        $_SESSION['fltrSgr'] = '';
        $_SESSION['msg'] = 'coucou ' . $_POST['login'];
		  // UTC paris
		  date_default_timezone_set('Europe/Paris');

        // On redirige vers le fichier admin.php
        //header('Location: http://localhost/toto/calendrier/liste.php');
		header('Location: liste.php');
        exit();
      }
    }
      else
    {
      $errorMessage = 'Veuillez inscrire vos identifiants svp !';
    }
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
  <head>
    <title>Formulaire chouchou</title>
  </head>
  <body>
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
      <fieldset>
        <legend>tu es qui</legend>
        <?php
          // Rencontre-t-on une erreur ?
          if(!empty($errorMessage)) 
          {
            echo '<p>', htmlspecialchars($errorMessage) ,'</p>';
          }
        ?>
       <p>
          <label for="login">qui :</label> 
          <input type="text" name="login" id="login" value="" />
          <input type="submit" name="submit" value="vazy" />
        </p>
      </fieldset>
    </form>
  </body>
</html>