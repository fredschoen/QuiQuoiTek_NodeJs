<?php
phpinfo();