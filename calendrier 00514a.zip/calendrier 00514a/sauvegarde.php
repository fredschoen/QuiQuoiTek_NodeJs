<?php
include("entetePHP.inc"); 
$NomPage="valider sauvegarde";
$NomPgRetour="liste";
$NomPgSuite="";

$mysqli =  new mysqli('localhost', 'admin', 'fred', "calendrier");
if ($mysqli->connect_errno) {
	echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
$fic="'C:/ProgramData/MySQL/MySQL Server 5.7/Uploads/data_calendrier_unload_"
. date("y m d H i s", time())
. ".txt'";

$req="SELECT * FROM evenements INTO OUTFILE " . $fic;

if ($mysqli->query($req)) {
	$msg="fichier de sauvegarde créé" . $fic;
}
else
{
	$msg= "echec creation: (" . $mysqli->errno . ") " . $mysqli->error . "<br>"
	. "$req: " . $req ;	
}
/* Libération du jeu de résultats */
$mysqli->close();

$_SESSION['msg'] = $msg;
echo $msg;
header('Location: liste.php');
exit();
