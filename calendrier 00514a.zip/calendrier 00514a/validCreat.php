<?php
include("entetePHP.inc"); 
$NomPage="valider ajout";
$NomPgRetour="liste";
$NomPgSuite="ajouter";
$msg="";
$mysqli =  new mysqli('localhost', 'admin', 'fred', "calendrier");
if ($mysqli->connect_errno) {
	echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
$res = $mysqli->query("select der from numeros WHERE typ='evenement'");
$row = $res->fetch_assoc();
$prochainNumero = $row['der']+1;
$res = $mysqli->query("update numeros set der =" .  $prochainNumero . "  where typ = 'evenement'");
$res = $mysqli->query("update numeros set der =" .  $prochainNumero . "  where typ = 'evenement'");

$req="INSERT INTO evenements (cod, grp, sgr, dat, inf) VALUE ("
 . "'" . 'evt' . $prochainNumero  . "'" . ', '
 . "'" . $_POST['grp'] . "'" .  ', ' 
 . "'" . $_POST['sgr'] . "'" .  ', ' 
 . "'" . $_POST['dat'] . "'" .  ', '
 . "'" . $_POST['inf'] . "'"
 . ')';
$msg="création de l'enreg "
.  $_POST['dat'] . "," 
.  $_POST['grp'] . "," 
.  $_POST['sgr'] . ":<br>" ;

if ($mysqli->query($req)) {
	$msg=$msg ."base de données mise à jour";
}
else
{
	$msg=$msg . "echec modification: (" . $mysqli->errno . ") " 
	 . "<br>" . "$req: " . $req;	
}
/* Libération du jeu de résultats */
$mysqli->close();

$_SESSION['msg'] = $msg;
echo $msg;
header('Location: liste.php');
exit();
