<?php
function controlDat($dat) {
    //echo ",,,,,,,,,,,,," . $dat . ",,,,,,,,,,,,," . strlen ( $dat) . ',,,,,,';

	//controle taille
    if (!( strlen ( $dat) === 5 )) {
        throw new Exception('format annee du critère annee erroné:' . substr($dat,1,4));
    }

	//controle taille
	$aaaa=(int) (substr($dat,1,4));

    if (!( $aaaa > 0 )) {
        throw new Exception('numericite annee du critère annee erroné:' . substr($dat,1,4));
    }

	//controle operateur
    if (!( 
	    ($dat[0] === '>' ) or
	    ($dat[0] === '<' ) or
	    ($dat[0] === '=' ) 
	    )) {
        throw new Exception('format operateur du critère annee erroné:"' . $dat[0] . '"');
    }
}

function calculWhereDat($dat) {
    //echo ",,,,,,,,,,,,," . $dat . ",,,,,,,,,,,,," . strlen ( $dat) . ',,,,,,';

	//mmjj 
    if ($dat[0]===">") {
		$mmjj = '-12-31';
	} elseif ($dat[0]==="<") {
		$mmjj="-01-01";
	} elseif ($dat[0]==="=") {
		$mmjjDeb="-12-31";
		$mmjjFin="-01-01";
	}

	//aaaa
	$aaaa=(int) (substr($dat,1,4));
    if ($dat[0]==="=") {
		$aaaaDeb=$aaaa-1;
		$aaaaFin=$aaaa+1;
	}
	//echo ',,,,' . $aaaa . ',,,,';

    //txt
    if ($dat[0]==="=") {
		$txt= '>' . "'" . $aaaaDeb . $mmjjDeb . "' "; 
		$txt= $txt . ' AND dat <' . "'" . $aaaaFin . $mmjjFin . "' "; 
	} else {
		$txt= $dat[0] . "'" . $aaaa . $mmjj . "'"; 
	}
	//echo ",,,,,,,,,,,,," . $txt . ",,,,,,,,,,,,,";

	//retour
	return $txt;
}
