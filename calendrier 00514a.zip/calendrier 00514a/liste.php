<?php
require("outils.php");
include("entetePHP.inc"); 
$NomPage="liste des événements";
$NomPgRetour="ajouter";
$NomPgSuite="";
$Msg="";
$mysqli =  new mysqli('localhost', 'admin', 'fred', "calendrier");
if ($mysqli->connect_errno) {
	echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

//nouvelles valeurs saisies
// - valeur passée en explicite
if (isset($_GET['tri']) ) $_SESSION['tri']= $_GET['tri']; 
// - valeur passée en POST (champs INPUT)
if (isset($_POST['fltrDat']) ) {
	try{
		 controlDat($_POST['fltrDat']);
	} catch (Exception $e) {
         //echo 'Exception reçue : ',  $e->getMessage(), "\n";
		 $_SESSION['msg'] = $e->getMessage();
	}
	// si pas d'erreur , le critère est noté
	if ($_SESSION['msg']==='') {
	   $_SESSION['fltrDat']= $_POST['fltrDat'];
	}
}	

if (isset($_POST['fltrGrp']) ) $_SESSION['fltrGrp']= $_POST['fltrGrp']; 
if (isset($_POST['fltrSgr']) ) $_SESSION['fltrSgr']= $_POST['fltrSgr']; 

//calcul phrase 'tri'
switch ($_SESSION['tri']) {
	 case "dd" :
	   $txtTri="dat DESC";
	   break;
	 case "ga":
	   $txtTri="grp ASC, dat ASC";
	   break;
	 case "gd" :
	   $txtTri="grp DESC, dat DESC";
	   break;
	 case "sa":
	   $txtTri="sgr ASC, grp ASC, dat ASC";
	   break;
	 case "sd" :
	   $txtTri="sgr DESC, grp DESC, dat DESC";
	   break;
	 default:
	   $txtTri="dat ASC";
	   break;
	}

// calcul des WHERE complémentaires
$where='';
// - dat
if ($_SESSION['fltrDat'] > '')
{
	if ($where > '') $where = $where . " AND ";	else $where = " WHERE ";
	$where = $where . " dat " . calculWhereDat($_SESSION['fltrDat']);
}
// - like grp %
if ($_SESSION['fltrGrp'] > '')
{
	if ($where > '') $where = $where . " AND ";	else $where = " WHERE ";
	$where = $where . " Grp like '" . $_SESSION['fltrGrp'] . "%'";
}
// - like sgr %
if ($_SESSION['fltrSgr'] > '')
{
	if ($where > '') $where = $where . " AND ";	else $where = " WHERE ";
	$where = $where . " Sgr like '" . $_SESSION['fltrSgr'] . "%'";
}
// requete
$req="select cod, grp, sgr, dat, inf from evenements" . $where . " ORDER BY " . $txtTri;
//echo ';;;;;;;;;;;;;;' . $req . ';;;;;;;;;;;;;;' ;

// exec requete
$res = $mysqli->query($req);
/////////////////////////////////////////////////////////
?>

<html>
<head>
<?php include("enteteHTML.inc"); ?>
</head>
<body>
<?php include("hautPage.inc"); ?>

<form name='formulairePg' action="liste.php" method="post">
<INPUT type=hidden name='cod' value=''> 
<INPUT type=hidden name='tri' value=''> 

<table cellSpacing=1 cellPadding=1 width="650" align=center border=0 >
<tr class=ligne>
<td>
<?php
if ($_SESSION['tri']==='da') echo "tri+";
else echo '<a href="liste.php?tri=da">tri+</a>';
echo '&nbsp';
if ($_SESSION['tri']==='dd') echo "tri-" ;
else echo '<a href="liste.php?tri=dd">tri-</a>';
?>
</td>
<td>
<?php
if ($_SESSION['tri']==='ga') echo "tri+";
else echo '<a href="liste.php?tri=ga">tri+</a>';
echo '&nbsp';
if ($_SESSION['tri']==='gd') echo "tri- " ;
else echo '<a href="liste.php?tri=gd">tri-</a>';
?>
</td>
<td>
<?php
if ($_SESSION['tri']==='sa') echo "tri+";
else echo '<a href="liste.php?tri=sa">tri+</a>';
echo '&nbsp';
if ($_SESSION['tri']==='sd') echo "tri-" ;
else echo '<a href="liste.php?tri=sd">tri-</a>';
?>
</td>
<td>
	d:<INPUT type="text" name="fltrDat" size="5" value="<?php echo $_SESSION['fltrDat']; ?>" /> 
	g:<INPUT type="text" name="fltrGrp" size="5" value="<?php echo $_SESSION['fltrGrp']; ?>" /> 
	s:<INPUT type="text" name="fltrSgr" size="5" value="<?php echo $_SESSION['fltrSgr']; ?>" /> 
</td>
<td>
    <INPUT type="submit" value="filtre" />
</td>
</tr>	
	<?php
	while ($row = $res->fetch_assoc()) {
	?>
<tr class=ligne>
<td width="13%"><?php echo $row['dat']; ?></td>
<td width="11%"><?php echo $row['grp']; ?></td>
<td width="11%"><?php echo $row['sgr']; ?></td>
<td width="45"><?php echo $row['inf'] ; ?></td>
<td width="20%">
<a onclick="SubForm('modifier.php',	<?php echo "'" . $row['cod'] . "'";?>)"; return false; href="#">modifier</a>
<a onclick="SubForm('supprimer.php',<?php echo "'" . $row['cod'] . "'";?>)"; return false; href="#">supprimer</a>
</td>
</tr>	
	<?php
	}
	/* Libération du jeu de résultats */
    $res->close();
	?>
</table>
</form>
<?php include("basPage.inc"); ?>
</body>
</html>
