<?php
include("entetePHP.inc"); 
$NomPage="confirmer suppression d un événement";
$NomPgRetour="liste";
$NomPgSuite="validSuppr";
$Msg="";
// relecture de l'enreg pour vérif en cas de modif parallele
$mysqli =  new mysqli('localhost', 'admin', 'fred', "calendrier");
if ($mysqli->connect_errno) {
	echo "Echec SubForm de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
$req="SELECT dat, grp, sgr, inf FROM evenements"
. " WHERE cod = '" . $_POST['cod'] . "'"
;
$res=$mysqli->query($req);

if (! $res) {
	echo "echec lecture: (" . $mysqli->errno . ") " . $mysqli->error . "<br>";
	echo "$req: " . $req . "<br>";	
}

$row = mysqli_fetch_assoc($res);
?>

<html>
<head>
<?php include("enteteHTML.inc"); ?>
</head>
<body>
<?php include("hautPage.inc"); ?>

<form name='formulairePg' action="" method="post">
<input type=hidden type="text" name="cod" value=<?php echo "'" . $_POST['cod'] . "'"; ?> >
<input type=hidden type="text" name="dat" value=<?php echo "'" . $row['dat'] . "'"; ?> >
<input type=hidden type="text" name="grp" value=<?php echo "'" . $row['grp'] . "'"; ?> >
<input type=hidden type="text" name="sgr" value=<?php echo "'" . $row['sgr'] . "'"; ?> >

<table cellSpacing=0 cellPadding=4 width="650" align=center border=0>  	

  <tr class=ligne>
  	<td> dat </td>
  	<td><?php echo $row['dat']; ?></td>
  </tr>

  <tr class=ligne>
  	<td> grp </td>
  	<td><?php echo $row['grp']; ?></td>
  </tr>

  <tr class=ligne>
  	<td> sgr </td>
  	<td><?php echo $row['sgr']; ?></td>
  </tr>

  <tr class=ligne>
  	<td> inf </td>
  	<td><?php echo $row['inf']; ?></td>
  </tr>
</table>
</form>
<?php include("basPage.inc"); ?>
</body>
</html>