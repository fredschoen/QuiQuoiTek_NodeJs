<?php
include("entetePHP.inc"); 
$NomPage="modifier un événement";
$NomPgRetour="liste";
$NomPgSuite="validModif";
$Msg="";
// relecture de l'enreg pour vérif en cas de modif parallele
$mysqli =  new mysqli('localhost', 'admin', 'fred', "calendrier");
if ($mysqli->connect_errno) {
	echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
$req="SELECT dat, grp, sgr, inf FROM evenements"
. " WHERE cod = '" . $_POST['cod'] . "'"
;
$res=$mysqli->query($req);

if (! $res) {
	echo "echec lecture: (" . $mysqli->errno . ") " . $mysqli->error . "<br>";
	echo "$req: " . $req . "<br>";	
}

$row = mysqli_fetch_assoc($res);
?>

<html>
<head>
<?php include("enteteHTML.inc"); ?>
</head>
<body>
<?php include("hautPage.inc"); ?>

<form name='formulairePg' action="validModif.php" method="post">
<input type=hidden type="text" name="cod" size="50" value=<?php echo "'" . $_POST['cod'] . "'"; ?> >

<table cellSpacing=0 cellPadding=4 width="650" align=center border=0>  	

  <tr class=ligne>
  	<td> dat </td>
  	<td><input type="text" name="dat" size="50" value="<?php echo $row['dat']; ?>"> </td>
  </tr>

  <tr class=ligne>
  	<td> grp </td>
  	<td><input type="text" name="grp" size="50" value="<?php echo $row['grp']; ?>"> </td>
  </tr>

  <tr class=ligne>
  	<td> sgr </td>
  	<td><input type="text" name="sgr" size="50" value="<?php echo $row['sgr']; ?>"> </td>
  </tr>

  <tr class=ligne>
  	<td> inf </td>
  	<td><input type="text" name="inf" size="50" value="<?php echo $row['inf']; ?>"> </td>
  </tr>
</table>
 <INPUT type="submit" value="" />
</form>
<?php include("basPage.inc"); ?>
</body>
</html>