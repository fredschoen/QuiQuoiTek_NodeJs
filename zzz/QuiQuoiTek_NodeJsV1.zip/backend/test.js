const num=12;
console.log(num.toString().padStart(6, "0"));